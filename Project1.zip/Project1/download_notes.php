<?php
require_once 'config.php';
require_once 'functions.php';

// Доступ только для авторизованных
requireLogin();

$isAdmin = isAdmin();
$userId = $_SESSION['user_id'];

// Если админ — качаем все заметки, если юзер — только свои
if ($isAdmin) {
    $sql = "SELECT n.*, u.login FROM notes n JOIN users u ON n.user_id = u.id ORDER BY n.created_at DESC";
    $stmt = mysqli_prepare($connection, $sql);
} else {
    $sql = "SELECT n.*, u.login FROM notes n JOIN users u ON n.user_id = u.id WHERE n.user_id = ? ORDER BY n.created_at DESC";
    $stmt = mysqli_prepare($connection, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $userId);
}

mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$notes = [];
while ($row = mysqli_fetch_assoc($result)) {
    $notes[] = [
        'id'            => (string)$row['id'], // В примере ID строка
        'title_user'    => $row['title'] . ' - ' . $row['login'], // Формат из примера
        'content'       => $row['content'],
        'formatted_date'=> date('d.m.Y', strtotime($row['created_at']))
    ];
}

// Настраиваем заголовки для скачивания файла
header('Content-Type: application/json; charset=utf-8');
header('Content-Disposition: attachment; filename="notes_' . date('Y-m-d') . '.json"');

// Выводим JSON с красивыми отступами (JSON_PRETTY_PRINT)
echo json_encode($notes, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
exit;