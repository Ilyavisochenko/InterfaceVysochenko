<?php
/**
 * backup.php — создание и скачивание бэкапа БД Vysochenko_bd
 * Доступ: только admin и sysadmin
 */
require_once 'config.php';
require_once 'functions.php';
requireAdmin();

// === Настройки ===
$backupDir   = __DIR__ . '/backups';
$keepLatest  = 10;                       // сколько последних хранить на сервере
$dbName      = DB_NAME;

// Создаём папку, если нет
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0750, true);
}

// === Определяем режим ===
$mode = $_GET['mode'] ?? 'download'; // download | list | delete

// ---------- СПИСОК БЭКАПОВ ----------
if ($mode === 'list') {
    $files = glob($backupDir . '/backup_*.sql.gz');
    $files = $files ?: [];
    usort($files, fn($a, $b) => filemtime($b) - filemtime($a));
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_map(function($f) {
        return [
            'name' => basename($f),
            'size' => round(filesize($f) / 1024, 1) . ' КБ',
            'date' => date('d.m.Y H:i:s', filemtime($f)),
        ];
    }, $files), JSON_UNESCAPED_UNICODE);
    exit;
}

// ---------- УДАЛЕНИЕ ----------
if ($mode === 'delete') {
    $file = basename($_GET['file'] ?? '');
    $path = $backupDir . '/' . $file;
    if (strpos($file, 'backup_') !== 0 || !is_file($path)) {
        $_SESSION['flash_msg'] = 'Файл не найден';
        $_SESSION['flash_type'] = 'error';
    } else {
        unlink($path);
        $_SESSION['flash_msg'] = "Файл $file удалён";
        $_SESSION['flash_type'] = 'success';
    }
    header('Location: admin.php?tab=db');
    exit;
}

// ---------- СОЗДАНИЕ И СКАЧИВАНИЕ ----------
$timestamp = date('Y-m-d_H-i-s');
$filename  = "backup_{$dbName}_{$timestamp}.sql";
$gzName    = $filename . '.gz';
$savePath  = $backupDir . '/' . $gzName;

// Пробуем mysqldump (сохраняет процедуры и триггеры)
$dumpOk = false;
if (function_exists('exec')) {
    $cmd = sprintf(
        'mysqldump --host=%s --user=%s --password=%s --default-character-set=utf8mb4 '
        . '--routines --triggers --single-transaction %s 2>&1',
        escapeshellarg('localhost'),
        escapeshellarg('admin'),
        escapeshellarg('admin'),
        escapeshellarg($dbName)
    );
    exec($cmd, $output, $code);
    if ($code === 0 && !empty($output)) {
        $sql = implode("\n", $output);
        file_put_contents($savePath, gzencode($sql, 6));
        $dumpOk = true;
    }
}

// Фолбэк: ручной дамп через SQL (если mysqldump недоступен)
if (!$dumpOk) {
    $sql = "-- Бэкап БД {$dbName}\n";
    $sql .= "-- Дата: " . date('Y-m-d H:i:s') . "\n";
    $sql .= "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n\n";

    $tablesRes = mysqli_query($connection, 'SHOW TABLES');
    while ($row = mysqli_fetch_row($tablesRes)) {
        $table = $row[0];
        $create = mysqli_fetch_assoc(mysqli_query($connection, "SHOW CREATE TABLE `{$table}`"));
        $sql .= "DROP TABLE IF EXISTS `{$table}`;\n";
        $sql .= $create['Create Table'] . ";\n\n";

        $dataRes = mysqli_query($connection, "SELECT * FROM `{$table}`");
        while ($r = mysqli_fetch_assoc($dataRes)) {
            $vals = array_map(function($v) use ($connection) {
                return $v === null ? 'NULL' : "'" . mysqli_real_escape_string($connection, $v) . "'";
            }, array_values($r));
            $sql .= "INSERT INTO `{$table}` VALUES (" . implode(',', $vals) . ");\n";
        }
        $sql .= "\n";
    }
    $sql .= "SET FOREIGN_KEY_CHECKS = 1;\n";

    // ⚠️ Процедуры и триггеры в фолбэке не экспортируются — нужен mysqldump
    file_put_contents($savePath, gzencode($sql, 6));
}

// Чистим старые бэкапы (оставляем $keepLatest)
$allBackups = glob($backupDir . '/backup_*.sql.gz') ?: [];
usort($allBackups, fn($a, $b) => filemtime($b) - filemtime($a));
if (count($allBackups) > $keepLatest) {
    foreach (array_slice($allBackups, $keepLatest) as $old) {
        unlink($old);
    }
}

// Скачиваем файл
header('Content-Type: application/gzip');
header('Content-Disposition: attachment; filename="' . $gzName . '"');
header('Content-Length: ' . filesize($savePath));
readfile($savePath);
exit;