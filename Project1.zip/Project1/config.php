<?php
define('DB_NAME', 'Vysochenko_bd');
// Управление сессией
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Показываем ошибки (потом уберём)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- ЛОКАЛЬНЫЙ MySQL ---
$host     = 'localhost';
$user     = 'admin';
$password = 'admin';
$database = 'Vysochenko_bd';

$connection = mysqli_connect($host, $user, $password, $database);

if (!$connection) {
    die('Ошибка подключения к БД: ' . mysqli_connect_error());
}

mysqli_set_charset($connection, 'utf8mb4');