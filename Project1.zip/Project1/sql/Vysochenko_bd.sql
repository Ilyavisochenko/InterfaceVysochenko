-- phpMyAdmin SQL Dump
-- version 5.2.3-1.red80
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Окт 19 2026 г., 06:58
-- Версия сервера: 10.11.16-MariaDB
-- Версия PHP: 8.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `Vysochenko_bd`
--

DELIMITER $$
--
-- Процедуры
--
CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_admin_add_user` (IN `p_login` VARCHAR(30), IN `p_password` VARCHAR(255), IN `p_first_name` VARCHAR(50), IN `p_last_name` VARCHAR(50), IN `p_middle_name` VARCHAR(50), IN `p_email` VARCHAR(100), IN `p_birthday` DATE, IN `p_role` VARCHAR(10), OUT `p_user_id` INT, OUT `p_message` VARCHAR(255))   BEGIN
  DECLARE v_login_exists INT DEFAULT 0;
  DECLARE v_email_exists INT DEFAULT 0;

  SELECT COUNT(*) INTO v_login_exists FROM `users` WHERE `login` = p_login;
  SELECT COUNT(*) INTO v_email_exists FROM `users` WHERE `email` = p_email;

  IF v_login_exists > 0 THEN
    SET p_user_id = NULL;
    SET p_message = 'Ошибка: пользователь с таким логином уже существует';
  ELSEIF v_email_exists > 0 THEN
    SET p_user_id = NULL;
    SET p_message = 'Ошибка: пользователь с таким email уже существует';
  ELSEIF p_role NOT IN ('user', 'admin') THEN
    SET p_user_id = NULL;
    SET p_message = 'Ошибка: некорректная роль';
  ELSE
    INSERT INTO `users`
      (`login`, `password`, `first_name`, `last_name`, `middle_name`,
       `email`, `birthday`, `role`, `is_blocked`)
    VALUES
      (p_login, p_password, p_first_name, p_last_name, p_middle_name,
       p_email, p_birthday, p_role, 0);

    SET p_user_id = LAST_INSERT_ID();
    SET p_message = 'OK: пользователь успешно добавлен';
  END IF;
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_admin_bulk_block` (IN `p_ids` TEXT, IN `p_block` TINYINT, OUT `p_message` VARCHAR(255))   BEGIN
  IF p_block = 1 THEN
    UPDATE `users` SET `is_blocked` = 1, `failed_attempts` = 0
    WHERE FIND_IN_SET(`id`, p_ids) > 0 AND `role` != 'sysadmin';
  ELSE
    UPDATE `users` SET `is_blocked` = 0, `failed_attempts` = 0
    WHERE FIND_IN_SET(`id`, p_ids) > 0;
  END IF;
  SET p_message = CONCAT('OK: обновлено пользователей: ', ROW_COUNT());
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_admin_delete_user` (IN `p_user_id` INT, OUT `p_message` VARCHAR(255))   BEGIN
  DECLARE v_role VARCHAR(10) DEFAULT NULL;
  SELECT `role` INTO v_role FROM `users` WHERE `id` = p_user_id;

  IF v_role IS NULL THEN
    SET p_message = 'Ошибка: пользователь не найден';
  ELSEIF v_role = 'sysadmin' THEN
    SET p_message = 'Ошибка: нельзя удалить супер-администратора';
  ELSE
    DELETE FROM `users` WHERE `id` = p_user_id;
    SET p_message = 'OK: пользователь удалён';
  END IF;
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_admin_toggle_block` (IN `p_user_id` INT, OUT `p_message` VARCHAR(255))   BEGIN
  DECLARE v_role  VARCHAR(10) DEFAULT NULL;
  DECLARE v_block TINYINT DEFAULT 0;

  SELECT `role`, `is_blocked` INTO v_role, v_block FROM `users` WHERE `id` = p_user_id;

  IF v_role IS NULL THEN
    SET p_message = 'Ошибка: пользователь не найден';
  ELSEIF v_role = 'sysadmin' THEN
    SET p_message = 'Ошибка: нельзя заблокировать супер-администратора';
  ELSE
    UPDATE `users` SET `is_blocked` = IF(v_block = 1, 0, 1), `failed_attempts` = IF(v_block = 1, 0, `failed_attempts`) WHERE `id` = p_user_id;
    SET p_message = IF(v_block = 1, 'OK: пользователь разблокирован', 'OK: пользователь заблокирован');
  END IF;
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_admin_update_user` (IN `p_user_id` INT, IN `p_first_name` VARCHAR(50), IN `p_last_name` VARCHAR(50), IN `p_middle_name` VARCHAR(50), IN `p_email` VARCHAR(100), IN `p_birthday` DATE, IN `p_role` VARCHAR(10), OUT `p_message` VARCHAR(255))   BEGIN
  DECLARE v_exists INT DEFAULT 0;
  DECLARE v_email_taken INT DEFAULT 0;

  SELECT COUNT(*) INTO v_exists FROM `users` WHERE `id` = p_user_id;

  SELECT COUNT(*) INTO v_email_taken
  FROM `users` WHERE `email` = p_email AND `id` <> p_user_id;

  IF v_exists = 0 THEN
    SET p_message = 'Ошибка: пользователь не найден';
  ELSEIF v_email_taken > 0 THEN
    SET p_message = 'Ошибка: этот email уже используется другим пользователем';
  ELSEIF p_role NOT IN ('user', 'admin') THEN
    SET p_message = 'Ошибка: некорректная роль';
  ELSE
    UPDATE `users`
    SET `first_name`  = p_first_name,
        `last_name`   = p_last_name,
        `middle_name` = p_middle_name,
        `email`       = p_email,
        `birthday`    = p_birthday,
        `role`        = p_role
    WHERE `id` = p_user_id;

    SET p_message = 'OK: данные пользователя обновлены';
  END IF;
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_change_password` (IN `p_user_id` INT, IN `p_new_password` VARCHAR(255), OUT `p_message` VARCHAR(255))   BEGIN
  DECLARE v_exists INT DEFAULT 0;

  SELECT COUNT(*) INTO v_exists FROM `users` WHERE `id` = p_user_id;

  IF v_exists = 0 THEN
    SET p_message = 'Ошибка: пользователь не найден';
  ELSE
    UPDATE `users` SET `password` = p_new_password WHERE `id` = p_user_id;
    SET p_message = 'OK: пароль изменён';
  END IF;
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_get_all_users` ()   BEGIN
  SELECT
    `id`, `login`, `first_name`, `last_name`, `middle_name`,
    `email`, `birthday`, `role`, `is_blocked`, `failed_attempts`, `created_at`
  FROM `users`
  ORDER BY `id`;
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_login_failed` (IN `p_login` VARCHAR(30), IN `p_max` INT, OUT `p_message` VARCHAR(255), OUT `p_blocked` TINYINT)   BEGIN
  DECLARE v_attempts INT DEFAULT 0;
  DECLARE v_id INT DEFAULT NULL;
  DECLARE v_role VARCHAR(10) DEFAULT NULL;

  SELECT `id`, `failed_attempts`, `role`
  INTO v_id, v_attempts, v_role
  FROM `users` WHERE `login` = p_login LIMIT 1;

  IF v_id IS NULL THEN
    SET p_message = 'Неверный логин или пароль';
    SET p_blocked = 0;
  ELSEIF v_role = 'admin' THEN
    SET p_message = 'Неверный логин или пароль';
    SET p_blocked = 0;
  ELSE
    SET v_attempts = v_attempts + 1;

    IF v_attempts >= p_max THEN
      UPDATE `users`
      SET `failed_attempts` = v_attempts,
          `last_failed_at`  = NOW(),
          `is_blocked`      = 1
      WHERE `id` = v_id;

      SET p_message = 'Вы заблокированы. Обратитесь к администратору';
      SET p_blocked = 1;
    ELSE
      UPDATE `users`
      SET `failed_attempts` = v_attempts,
          `last_failed_at`  = NOW()
      WHERE `id` = v_id;

      SET p_message = CONCAT('Неверные данные. Осталось попыток: ', p_max - v_attempts);
      SET p_blocked = 0;
    END IF;
  END IF;
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_login_success` (IN `p_user_id` INT)   BEGIN
  UPDATE `users`
  SET `failed_attempts` = 0,
      `last_failed_at`  = NULL
  WHERE `id` = p_user_id;
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_login_user` (IN `p_login` VARCHAR(30), OUT `p_user_id` INT, OUT `p_role` VARCHAR(10), OUT `p_blocked` TINYINT, OUT `p_message` VARCHAR(255))   BEGIN
  DECLARE v_id INT DEFAULT NULL;
  DECLARE v_role VARCHAR(10) DEFAULT NULL;
  DECLARE v_block TINYINT DEFAULT 0;

  SELECT `id`, `role`, `is_blocked`
  INTO v_id, v_role, v_block
  FROM `users` WHERE `login` = p_login LIMIT 1;

  IF v_id IS NULL THEN
    SET p_user_id = NULL;
    SET p_role = NULL;
    SET p_blocked = 0;
    SET p_message = 'Неверный логин или пароль';
  ELSEIF v_block = 1 THEN
    SET p_user_id = v_id;
    SET p_role = v_role;
    SET p_blocked = 1;
    SET p_message = 'Вы заблокированы. Обратитесь к администратору';
  ELSE
    SET p_user_id = v_id;
    SET p_role = v_role;
    SET p_blocked = 0;
    SET p_message = 'OK';
  END IF;
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `sp_register_user` (IN `p_login` VARCHAR(30), IN `p_password` VARCHAR(255), IN `p_first_name` VARCHAR(50), IN `p_last_name` VARCHAR(50), IN `p_middle_name` VARCHAR(50), IN `p_email` VARCHAR(100), IN `p_birthday` DATE, OUT `p_user_id` INT, OUT `p_message` VARCHAR(255))   BEGIN
  DECLARE v_login_exists INT DEFAULT 0;
  DECLARE v_email_exists INT DEFAULT 0;

  SELECT COUNT(*) INTO v_login_exists FROM `users` WHERE `login` = p_login;
  SELECT COUNT(*) INTO v_email_exists FROM `users` WHERE `email` = p_email;

  IF v_login_exists > 0 THEN
    SET p_user_id = NULL;
    SET p_message = 'Ошибка: логин уже занят';
  ELSEIF v_email_exists > 0 THEN
    SET p_user_id = NULL;
    SET p_message = 'Ошибка: email уже зарегистрирован';
  ELSE
    INSERT INTO `users` 
      (`login`, `password`, `first_name`, `last_name`, `middle_name`, `email`, `birthday`, `role`)
    VALUES 
      (p_login, p_password, p_first_name, p_last_name, p_middle_name, p_email, p_birthday, 'user');
    SET p_user_id = LAST_INSERT_ID();
    SET p_message = 'OK: пользователь зарегистрирован';
  END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `notes`
--

CREATE TABLE `notes` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `notes`
--

INSERT INTO `notes` (`id`, `user_id`, `title`, `content`, `created_at`) VALUES
(1, 1, 'Первая заметка', 'Сделать модуль заметок и JSON.', '2026-10-19 06:44:00'),
(2, 1, 'Планы на день', 'Проверить работу админ-панели.', '2026-10-19 06:44:00'),
(3, 6, 'Создание заментки', 'Админ создал заметку', '2026-10-19 06:57:28');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `login` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `birthday` date NOT NULL,
  `role` enum('user','admin','sysadmin') NOT NULL DEFAULT 'user',
  `is_blocked` tinyint(1) NOT NULL DEFAULT 0,
  `failed_attempts` int(11) NOT NULL DEFAULT 0,
  `last_failed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `first_name`, `last_name`, `middle_name`, `email`, `birthday`, `role`, `is_blocked`, `failed_attempts`, `last_failed_at`, `created_at`) VALUES
(1, 'petr', '$2y$10$MZcZZ8TRW.CjBYmpO.t3o.yRDPmBQ/dh0AHnWXRnXK2QBwuEIIO2u', 'Пётр', 'Петров', 'Петрович', 'admin@gmail.com', '1990-06-15', 'sysadmin', 0, 0, NULL, '2026-10-05 06:50:49'),
(2, 'Kolenka94', '$2y$10$ofKfevyA8EEXxjVpWPHmK.CB5M2Wu6sSOz4To6HTCWetAm5mOPifW', 'Виталий', 'Павлов', 'Николаевич', 'kolya42@gmail.com', '1997-09-01', 'user', 0, 0, NULL, '2026-10-08 02:22:53'),
(5, 'grishasamoletov', '$2y$10$0r71FYVMC0kbhzssQ7SFeeaVgtTKYdnY1q.78L/K.u0sHvHaXFcx2', 'Гриша', 'Самолетов', 'Кириллович', 'grishasamoletov42@gmail.com', '1995-10-01', 'user', 0, 0, NULL, '2026-10-08 04:33:19'),
(6, 'mokesio', '$2y$10$Bq8Wa3JA5xtY5qTZ//Ga6O0RExiF2Tkz17IFnynEMCCBv5JgvNRBK', 'Эмиль', 'Хаштаров', 'Алибекович', 'mokes@gmail.com', '1999-12-12', 'admin', 0, 0, NULL, '2026-10-12 06:55:11');

--
-- Триггеры `users`
--
DELIMITER $$
CREATE TRIGGER `trg_users_after_insert` AFTER INSERT ON `users` FOR EACH ROW BEGIN
  INSERT INTO `users_log` (`user_id`, `action`, `details`)
  VALUES (
    NEW.id,
    'REGISTER',
    CONCAT('Зарегистрирован пользователь: ', NEW.login, ' (', NEW.email, ')')
  );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_users_after_update` AFTER UPDATE ON `users` FOR EACH ROW BEGIN
  -- Смена роли
  IF OLD.role <> NEW.role THEN
    INSERT INTO `users_log` (`user_id`, `action`, `details`, `old_value`, `new_value`, `admin_id`)
    VALUES (NEW.id, 'ROLE_CHANGE', CONCAT('Роль: ', NEW.login), OLD.role, NEW.role, @admin_id);
  END IF;

  -- Блокировка
  IF OLD.is_blocked <> NEW.is_blocked THEN
    INSERT INTO `users_log` (`user_id`, `action`, `details`, `old_value`, `new_value`, `admin_id`)
    VALUES (
      NEW.id, 
      IF(NEW.is_blocked = 1, 'BLOCKED', 'UNBLOCKED'), 
      CONCAT('Статус: ', NEW.login),
      IF(OLD.is_blocked = 1, 'да', 'нет'), 
      IF(NEW.is_blocked = 1, 'да', 'нет'),
      @admin_id
    );
  END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_users_before_insert` BEFORE INSERT ON `users` FOR EACH ROW BEGIN
  -- Логин: длина
  IF CHAR_LENGTH(NEW.login) < 3 OR CHAR_LENGTH(NEW.login) > 30 THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: логин должен быть от 3 до 30 символов';
  END IF;

  -- Логин: только латиница, цифры, _ и -
  IF NEW.login NOT REGEXP '^[A-Za-z0-9_-]+$' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: логин может содержать только латиницу, цифры, _ и -';
  END IF;

  -- Имя: длина
  IF CHAR_LENGTH(NEW.first_name) < 2 OR CHAR_LENGTH(NEW.first_name) > 50 THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: имя должно быть от 2 до 50 символов';
  END IF;

  -- Фамилия: длина
  IF CHAR_LENGTH(NEW.last_name) < 2 OR CHAR_LENGTH(NEW.last_name) > 50 THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: фамилия должна быть от 2 до 50 символов';
  END IF;

  -- Отчество: длина
  IF CHAR_LENGTH(NEW.middle_name) < 2 OR CHAR_LENGTH(NEW.middle_name) > 50 THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: отчество должно быть от 2 до 50 символов';
  END IF;

  -- Email: нет пробелов
  IF NEW.email LIKE '% %' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email не должен содержать пробелов';
  END IF;

  -- Email: есть собака
  IF NEW.email NOT LIKE '%@%' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email должен содержать символ @';
  END IF;

  -- Email: только одна собака
  IF (CHAR_LENGTH(NEW.email) - CHAR_LENGTH(REPLACE(NEW.email, '@', ''))) <> 1 THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email должен содержать ровно один символ @';
  END IF;

  -- Email: собака не в начале
  IF NEW.email LIKE '@%' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email не может начинаться с @';
  END IF;

  -- Email: собака не в конце
  IF NEW.email LIKE '%@' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email не может заканчиваться на @';
  END IF;

  -- Email: точка после собаки
  IF SUBSTRING_INDEX(NEW.email, '@', -1) NOT LIKE '%.%' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: после @ должна быть точка (например, example.com)';
  END IF;

  -- Email: нет двух точек подряд
  IF NEW.email LIKE '%..%' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email не должен содержать две точки подряд';
  END IF;

  -- Email: длина
  IF CHAR_LENGTH(NEW.email) < 6 OR CHAR_LENGTH(NEW.email) > 100 THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email должен быть от 6 до 100 символов';
  END IF;

  -- Дата рождения: не в будущем
  IF NEW.birthday > CURDATE() THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: дата рождения не может быть в будущем';
  END IF;

  -- Дата рождения: не старше 120 лет
  IF NEW.birthday < DATE_SUB(CURDATE(), INTERVAL 120 YEAR) THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: возраст не может превышать 120 лет';
  END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_users_before_update` BEFORE UPDATE ON `users` FOR EACH ROW BEGIN
  IF CHAR_LENGTH(NEW.login) < 3 OR CHAR_LENGTH(NEW.login) > 30 THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: логин должен быть от 3 до 30 символов';
  END IF;

  IF NEW.login NOT REGEXP '^[A-Za-z0-9_-]+$' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: логин может содержать только латиницу, цифры, _ и -';
  END IF;

  IF CHAR_LENGTH(NEW.first_name) < 2 OR CHAR_LENGTH(NEW.first_name) > 50 THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: имя должно быть от 2 до 50 символов';
  END IF;

  IF CHAR_LENGTH(NEW.last_name) < 2 OR CHAR_LENGTH(NEW.last_name) > 50 THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: фамилия должна быть от 2 до 50 символов';
  END IF;

  IF CHAR_LENGTH(NEW.middle_name) < 2 OR CHAR_LENGTH(NEW.middle_name) > 50 THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: отчество должно быть от 2 до 50 символов';
  END IF;

  IF NEW.email LIKE '% %' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email не должен содержать пробелов';
  END IF;

  IF NEW.email NOT LIKE '%@%' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email должен содержать символ @';
  END IF;

  IF (CHAR_LENGTH(NEW.email) - CHAR_LENGTH(REPLACE(NEW.email, '@', ''))) <> 1 THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email должен содержать ровно один символ @';
  END IF;

  IF NEW.email LIKE '@%' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email не может начинаться с @';
  END IF;

  IF NEW.email LIKE '%@' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email не может заканчиваться на @';
  END IF;

  IF SUBSTRING_INDEX(NEW.email, '@', -1) NOT LIKE '%.%' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: после @ должна быть точка (например, example.com)';
  END IF;

  IF NEW.email LIKE '%..%' THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email не должен содержать две точки подряд';
  END IF;

  IF CHAR_LENGTH(NEW.email) < 6 OR CHAR_LENGTH(NEW.email) > 100 THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: email должен быть от 6 до 100 символов';
  END IF;

  IF NEW.birthday > CURDATE() THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: дата рождения не может быть в будущем';
  END IF;

  IF NEW.birthday < DATE_SUB(CURDATE(), INTERVAL 120 YEAR) THEN
    SIGNAL SQLSTATE '45000' 
      SET MESSAGE_TEXT = 'Ошибка: возраст не может превышать 120 лет';
  END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `users_log`
--

CREATE TABLE `users_log` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `action` varchar(30) NOT NULL,
  `details` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `old_value` varchar(50) DEFAULT NULL,
  `new_value` varchar(50) DEFAULT NULL,
  `admin_id` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users_log`
--

INSERT INTO `users_log` (`id`, `user_id`, `action`, `details`, `created_at`, `old_value`, `new_value`, `admin_id`) VALUES
(1, 3, 'REGISTER', 'Зарегистрирован пользователь: test_log (test_log@test.ru)', '2026-10-08 03:31:52', NULL, NULL, NULL),
(2, 4, 'REGISTER', 'Зарегистрирован пользователь: Ilya64 (Ilya64@gmail.com)', '2026-10-08 04:31:30', NULL, NULL, NULL),
(3, 5, 'REGISTER', 'Зарегистрирован пользователь: grishasamoletov (grishasamoletov42@gmail.com)', '2026-10-08 04:33:19', NULL, NULL, NULL),
(4, 6, 'REGISTER', 'Зарегистрирован пользователь: mokesio (mokes@gmail.com)', '2026-10-12 06:55:11', NULL, NULL, NULL),
(5, 3, 'NAME_CHANGE', 'ФИО изменено у test_log', '2026-10-12 07:17:24', NULL, NULL, NULL),
(6, 1, 'PASSWORD_CHANGE', 'Смена пароля: petr', '2026-10-12 07:30:19', NULL, NULL, NULL),
(7, 1, 'EMAIL_CHANGE', 'Email: petr@example.com → admin@gmail.com', '2026-10-12 07:31:01', NULL, NULL, NULL),
(8, 2, 'BLOCKED', 'Статус: Kolenka94', '2026-10-19 06:33:03', 'нет', 'да', 1),
(9, 2, 'UNBLOCKED', 'Статус: Kolenka94', '2026-10-19 06:33:07', 'да', 'нет', 1),
(10, 1, 'ROLE_CHANGE', 'Роль: petr', '2026-10-19 06:39:09', 'admin', 'sysadmin', NULL),
(11, 6, 'ROLE_CHANGE', 'Роль: mokesio', '2026-10-19 06:39:19', 'user', 'admin', 1),
(12, 5, 'BLOCKED', 'Статус: grishasamoletov', '2026-10-19 06:41:12', 'нет', 'да', 6),
(13, 5, 'UNBLOCKED', 'Статус: grishasamoletov', '2026-10-19 06:41:16', 'да', 'нет', 6);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login_unique` (`login`),
  ADD UNIQUE KEY `email_unique` (`email`);

--
-- Индексы таблицы `users_log`
--
ALTER TABLE `users_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_action` (`action`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `users_log`
--
ALTER TABLE `users_log`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
