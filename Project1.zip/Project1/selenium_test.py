import time
import json
import psutil
import platform
import urllib.request
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# === 1. СБОР ХАРАКТЕРИСТИК КОМПЬЮТЕРА ===
def get_system_stats():
    # Скорость интернета (загрузка тестового файла)
    start_time = time.time()
    try:
        urllib.request.urlopen('http://ipv4.download.thinkbroadband.com/1MB.zip', timeout=5)
        speed_mbps = round((1 / (time.time() - start_time)) * 8, 2)
    except:
        speed_mbps = "Не удалось измерить"

    return {
        "os": platform.system() + " " + platform.release(),
        "cpu_percent": psutil.cpu_percent(interval=1),
        "ram_total_gb": round(psutil.virtual_memory().total / (1024**3), 2),
        "ram_percent": psutil.virtual_memory().percent,
        "disk_free_gb": round(psutil.disk_usage('/').free / (1024**3), 2),
        "internet_speed_mbps": speed_mbps
    }

# === 2. АВТОМАТИЗАЦИЯ БРАУЗЕРА (SELENIUM) ===
def run_test():
    print("Сбор данных о системе...")
    stats = get_system_stats()
    
    print("Запуск браузера...")
    # Если нужно тестировать phpMyAdmin, раскомментируй нужный URL
    url = "http://localhost:3000/login.php" 
    
    driver = webdriver.Chrome() 
    driver.get(url)
    
    result = {
        "system_stats": stats,
        "login_status": "failed",
        "user_role": None
    }

    try:
        # 1. Вводим логин и пароль (ищем поля по name или id)
        # Для твоего сайта поля называются name="login" и name="password"
        login_input = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.NAME, "login"))
        )
        password_input = driver.find_element(By.NAME, "password")
        
        login_input.send_keys("petr")
        password_input.send_keys("admin123")
        
        # 2. РЕШЕНИЕ КАПЧИ-ПАЗЛА
        # В твоей капче 4 элемента, правильный порядок: 1, 2, 3, 4
        # Находим все плитки
        pieces = driver.find_elements(By.CSS_SELECTOR, ".puzzle-piece")
        
        # В Selenium сложно делать Drag & Drop, поэтому мы можем 
        # просто вписать правильный ответ в скрытое поле, если JS не мешает
        # (Но если препод требует именно клики, нужно использовать ActionChains)
        
        # Обходной путь: пишем в скрытое поле правильный порядок
        order_input = driver.find_element(By.ID, "captchaOrder")
        driver.execute_script("arguments[0].value = '1,2,3,4';", order_input)
        
        # 3. Нажимаем кнопку "Войти"
        submit_btn = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
        submit_btn.click()
        
        # Ждем загрузки страницы
        time.sleep(2) 
        
        # 4. Проверяем, авторизовались ли мы
        if "index.php" in driver.current_url or "Вы вошли как" in driver.page_source:
            result["login_status"] = "success"
            
            # Ищем роль на странице (например, в тексте "роль: sysadmin")
            if "sysadmin" in driver.page_source: result["user_role"] = "sysadmin"
            elif "admin" in driver.page_source: result["user_role"] = "admin"
            else: result["user_role"] = "user"
            
            print(f"УСПЕХ! Авторизовались как {result['user_role']}")
        else:
            print("ОШИБКА: Не удалось авторизоваться (возможно, неверный пароль или капча).")

    except Exception as e:
        print(f"Ошибка при выполнении: {e}")
    
    finally:
        driver.quit()
        
        # === 3. ЗАПИСЬ В JSON ===
        with open('selenium_report.json', 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=4)
        print("Отчет сохранен в selenium_report.json")

if __name__ == "__main__":
    run_test()