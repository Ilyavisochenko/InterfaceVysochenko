<?php
require_once 'config.php';
require_once 'functions.php';

requireLogin();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
    <h1>👤 Личный кабинет</h1>

    <div class="menu">
        <a href="index.php" class="btn btn-secondary">← На главную</a>
        <a href="change_password.php" class="btn">🔒 Сменить пароль</a>
        <?php if (isAdmin()): ?>
            <a href="admin.php" class="btn">🛡 Админ-панель</a>
        <?php endif; ?>
        <a href="logout.php" class="btn btn-danger">🚪 Выйти</a>
    </div>

    <table class="profile-table">
        <tr><th>ID</th><td><?= e($_SESSION['user_id']) ?></td></tr>
        <tr><th>Логин</th><td><?= e($_SESSION['login']) ?></td></tr>
        <tr><th>Имя</th><td><?= e($_SESSION['first_name']) ?></td></tr>
        <tr><th>Фамилия</th><td><?= e($_SESSION['last_name']) ?></td></tr>
        <tr><th>Отчество</th><td><?= e($_SESSION['middle_name']) ?></td></tr>
        <tr><th>Email</th><td><?= e($_SESSION['email']) ?></td></tr>
        <tr><th>Роль</th><td><?= e($_SESSION['role']) ?></td></tr>
    </table>
</div>
</body>
</html>