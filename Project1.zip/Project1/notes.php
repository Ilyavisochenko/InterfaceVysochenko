<?php
require_once 'config.php';
require_once 'functions.php';

requireLogin(); // Доступ только после входа

$isAdmin = isAdmin();
$userId = $_SESSION['user_id'];
$message = '';

// === ДОБАВЛЕНИЕ НОВОЙ ЗАМЕТКИ ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_note'])) {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    
    if ($title !== '' && $content !== '') {
        $stmt = mysqli_prepare($connection, 'INSERT INTO notes (user_id, title, content) VALUES (?, ?, ?)');
        mysqli_stmt_bind_param($stmt, 'iss', $userId, $title, $content);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        
        $_SESSION['flash_msg'] = 'Заметка успешно добавлена!';
        $_SESSION['flash_type'] = 'success';
        header('Location: notes.php');
        exit;
    } else {
        $message = 'Заполните заголовок и текст заметки.';
    }
}

// Сообщение из сессии
if (isset($_SESSION['flash_msg'])) {
    $message = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

// === ПОЛУЧЕНИЕ ЗАМЕТОК ===
$notes = [];
if ($isAdmin) {
    $sql = "SELECT n.*, u.login FROM notes n JOIN users u ON n.user_id = u.id ORDER BY n.created_at DESC";
    $stmt = mysqli_prepare($connection, $sql);
} else {
    $sql = "SELECT n.*, u.login FROM notes n JOIN users u ON n.user_id = u.id WHERE n.user_id = ? ORDER BY n.created_at DESC";
    $stmt = mysqli_prepare($connection, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $userId);
}

mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
while ($row = mysqli_fetch_assoc($res)) $notes[] = $row;
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Заметки</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
             .note-card {
            background: #ffffff;
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 16px 20px;
            margin-bottom: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05), 0 1px 2px rgba(0,0,0,0.03);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            transition: all 0.2s ease;
        }
        
        .note-card:hover {
            border-color: var(--border-hover);
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05), 0 2px 4px -1px rgba(0,0,0,0.03);
            transform: translateY(-1px);
        }

        .note-info h4 { 
            margin: 0 0 8px 0; 
            font-size: 16px; 
            color: var(--text-main); 
            font-weight: 600; 
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Красивая плашка для имени автора */
        .note-author {
            font-size: 12px;
            background: var(--bg-hover);
            color: var(--text-soft);
            padding: 2px 8px;
            border-radius: 6px;
            font-weight: 500;
            border: 1px solid var(--border);
        }

        .note-info p { 
            margin: 0; 
            font-size: 14px; 
            color: var(--text-soft); 
            line-height: 1.5;
        }

        .note-date { 
            font-size: 12.5px; 
            color: var(--text-mute); 
            margin-top: 12px; 
            display: flex; 
            align-items: center; 
            gap: 6px; 
        }

        .note-id { 
            font-size: 12px; 
            color: var(--text-soft); 
            font-family: monospace; 
            background: var(--bg-hover); 
            padding: 4px 8px; 
            border-radius: 6px; 
            border: 1px solid var(--border);
        }
        
        .add-note-form {
            background: var(--md-surface-1);
            padding: 20px;
            border-radius: var(--r-md);
            margin-bottom: 30px;
            border: 1px solid var(--md-outline-var);
        }
    </style>
</head>
<body>
<div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h1>📝 Заметки</h1>
        <div style="display: flex; gap: 10px;">
            <a href="download_notes.php" class="btn btn-primary" style="background: #238636; border-color: #238636;">⬇️ Скачать JSON</a>
            <a href="index.php" class="btn btn-secondary">← На главную</a>
            <a href="logout.php" class="btn btn-danger">Выйти</a>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success" style="padding: 10px; margin-bottom: 20px; border-radius: 6px; background: #3fb95022; color: #3fb950; border: 1px solid currentColor;">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <div style="font-size: 13px; color: var(--md-on-surface-var); margin-bottom: 16px;">
        Пользователь: <strong><?= e($_SESSION['login']) ?></strong> | Роль: <strong><?= e($_SESSION['role']) ?></strong> | Показано: <strong><?= count($notes) ?></strong>
    </div>

    <?php if ($isAdmin): ?>
        <div class="alert alert-info" style="margin-bottom: 20px; font-size: 13px; padding: 10px; background: rgba(88, 166, 255, 0.1); color: #58a6ff; border: 1px solid rgba(88, 166, 255, 0.3); border-radius: 6px;">
            ℹ️ Вы видите все заметки всех пользователей.
        </div>
    <?php endif; ?>

    <!-- Форма добавления -->
    <div class="add-note-form">
        <h3 style="margin-top: 0; margin-bottom: 12px; font-size: 16px;">➕ Добавить заметку</h3>
        <form method="post">
            <input type="text" name="title" placeholder="Заголовок заметки..." required style="margin-bottom: 10px;">
            <textarea name="content" placeholder="Текст заметки..." required style="margin-bottom: 10px; min-height: 80px; resize: vertical;"></textarea>
            <button type="submit" name="add_note" class="btn btn-primary">Сохранить</button>
        </form>
    </div>

    <!-- Список заметок -->
    <?php if (empty($notes)): ?>
        <p style="color: var(--md-on-surface-var); font-size: 14px; text-align: center;">Заметок пока нет. Создайте первую!</p>
    <?php else: ?>
        <?php foreach ($notes as $n): ?>
            <div class="note-card">
                <div class="note-info">
                    <h4><?= e($n['title']) ?> — <?= e($n['login']) ?></h4>
                    <p><?= nl2br(e($n['content'])) ?></p>
                    <div class="note-date">
                        📅 <?= date('d.m.Y', strtotime($n['created_at'])) ?>
                    </div>
                </div>
                <div class="note-id">#<?= str_pad($n['id'], 5, '0', STR_PAD_LEFT) ?></div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

</div>
</body>
</html>