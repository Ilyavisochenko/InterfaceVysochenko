<?php
require_once 'config.php';
require_once 'functions.php';

requireLogin();

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $oldPassword = $_POST['old_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirm     = $_POST['confirm_password'] ?? '';

    // Проверка заполнения
    if ($oldPassword === '') $errors['old_password'] = 'Введите текущий пароль';
    if ($newPassword === '') $errors['new_password'] = 'Введите новый пароль';
    if ($confirm === '')     $errors['confirm_password'] = 'Подтвердите новый пароль';

    // Проверка нового пароля
    if (empty($errors['new_password'])) {
        if ($e = validatePassword($newPassword)) {
            $errors['new_password'] = $e;
        }
    }

    // Совпадение паролей
    if ($newPassword !== $confirm) {
        $errors['confirm_password'] = 'Пароли не совпадают';
    }

    // Проверка старого пароля
    if (empty($errors['old_password'])) {
        $stmt = mysqli_prepare($connection,
            'SELECT password FROM users WHERE id = ? LIMIT 1');
        mysqli_stmt_bind_param($stmt, 'i', $_SESSION['user_id']);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($res);
        mysqli_stmt_close($stmt);

        if (!$row || !password_verify($oldPassword, $row['password'])) {
            $errors['old_password'] = 'Неверный текущий пароль';
        }
    }

    // Если ошибок нет — меняем
    if (empty($errors)) {
        $newHash = password_hash($newPassword, PASSWORD_DEFAULT);

        $stmt = mysqli_prepare($connection,
            'UPDATE users SET password = ? WHERE id = ?');
        mysqli_stmt_bind_param($stmt, 'si', $newHash, $_SESSION['user_id']);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $success = 'Пароль успешно изменён!';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Смена пароля</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
    <h1>🔒 Смена пароля</h1>

    <?php if ($success): ?>
        <div class="success"><?= e($success) ?></div>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <div class="error">Проверьте правильность заполнения полей</div>
    <?php endif; ?>

    <form method="post" novalidate>
        <label>Текущий пароль</label>
        <input type="password" name="old_password" required>
        <?php if (!empty($errors['old_password'])): ?>
            <span class="field-error"><?= e($errors['old_password']) ?></span>
        <?php endif; ?>

        <label>Новый пароль (минимум 8 символов)</label>
        <input type="password" name="new_password" required>
        <?php if (!empty($errors['new_password'])): ?>
            <span class="field-error"><?= e($errors['new_password']) ?></span>
        <?php endif; ?>

        <label>Подтвердите новый пароль</label>
        <input type="password" name="confirm_password" required>
        <?php if (!empty($errors['confirm_password'])): ?>
            <span class="field-error"><?= e($errors['confirm_password']) ?></span>
        <?php endif; ?>

        <button type="submit">💾 Сменить пароль</button>
    </form>

    <p style="margin-top:20px; text-align:center;">
        <a href="profile.php" class="link">← Вернуться в профиль</a>
    </p>
</div>
</body>
</html>