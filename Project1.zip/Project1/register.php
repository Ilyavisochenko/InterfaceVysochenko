<?php
require_once 'config.php';
require_once 'functions.php';

// Уже авторизован — на главную
if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$errors = [];
$old = [
    'login' => '', 'first_name' => '', 'last_name' => '',
    'middle_name' => '', 'email' => '', 'birthday' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login       = trim($_POST['login']       ?? '');
    $password    = $_POST['password']         ?? '';
    $firstName   = trim($_POST['first_name']  ?? '');
    $lastName    = trim($_POST['last_name']   ?? '');
    $middleName  = trim($_POST['middle_name'] ?? '');
    $email       = trim($_POST['email']       ?? '');
    $birthday    = trim($_POST['birthday']    ?? '');

    $old = [
        'login' => $login, 'first_name' => $firstName, 'last_name' => $lastName,
        'middle_name' => $middleName, 'email' => $email, 'birthday' => $birthday,
    ];

    // Валидация полей
    if ($e = validateLogin($login))          $errors['login']       = $e;
    if ($e = validatePassword($password))    $errors['password']    = $e;
    if ($e = validateName($firstName, 'Имя'))       $errors['first_name']  = $e;
    if ($e = validateName($lastName, 'Фамилия'))    $errors['last_name']   = $e;
    if ($e = validateName($middleName, 'Отчество')) $errors['middle_name'] = $e;
    if ($e = validateEmail($email))          $errors['email']       = $e;
    if ($e = validateBirthday($birthday))    $errors['birthday']    = $e;

    // Если ошибок нет — регистрируем
    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = mysqli_prepare($connection,
            'CALL sp_register_user(?, ?, ?, ?, ?, ?, ?, @uid, @msg)');
        mysqli_stmt_bind_param($stmt, 'sssssss',
            $login, $hash, $firstName, $lastName, $middleName, $email, $birthday);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        while (mysqli_more_results($connection) && mysqli_next_result($connection)) {}

        $res = mysqli_query($connection, 'SELECT @uid AS uid, @msg AS msg');
        $row = mysqli_fetch_assoc($res);

        if (!empty($row['uid'])) {
            $_SESSION['flash_success'] = 'Регистрация успешна! Войдите.';
            header('Location: login.php');
            exit;
        } else {
            $errors['general'] = $row['msg'] ?? 'Ошибка регистрации';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
    <h1>📝 Регистрация</h1>

    <?php if (!empty($errors['general'])): ?>
        <div class="error"><?= e($errors['general']) ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
        <label>Имя</label>
        <input type="text" name="first_name" value="<?= e($old['first_name']) ?>" required>
        <?php if (!empty($errors['first_name'])): ?>
            <span class="field-error"><?= e($errors['first_name']) ?></span>
        <?php endif; ?>

        <label>Фамилия</label>
        <input type="text" name="last_name" value="<?= e($old['last_name']) ?>" required>
        <?php if (!empty($errors['last_name'])): ?>
            <span class="field-error"><?= e($errors['last_name']) ?></span>
        <?php endif; ?>

        <label>Отчество</label>
        <input type="text" name="middle_name" value="<?= e($old['middle_name']) ?>" required>
        <?php if (!empty($errors['middle_name'])): ?>
            <span class="field-error"><?= e($errors['middle_name']) ?></span>
        <?php endif; ?>

        <label>Логин</label>
        <input type="text" name="login" value="<?= e($old['login']) ?>" required>
        <?php if (!empty($errors['login'])): ?>
            <span class="field-error"><?= e($errors['login']) ?></span>
        <?php endif; ?>

        <label>Email</label>
        <input type="text" name="email" value="<?= e($old['email']) ?>" required>
        <?php if (!empty($errors['email'])): ?>
            <span class="field-error"><?= e($errors['email']) ?></span>
        <?php endif; ?>

        <label>Дата рождения</label>
        <input type="date" name="birthday" value="<?= e($old['birthday']) ?>" required>
        <?php if (!empty($errors['birthday'])): ?>
            <span class="field-error"><?= e($errors['birthday']) ?></span>
        <?php endif; ?>

        <label>Пароль (минимум 8 символов)</label>
        <input type="password" name="password" required>
        <?php if (!empty($errors['password'])): ?>
            <span class="field-error"><?= e($errors['password']) ?></span>
        <?php endif; ?>

        <button type="submit" style="width:100%; margin-top:10px;">Зарегистрироваться</button>
    </form>

    <p style="margin-top:20px; text-align:center;">
        Уже есть аккаунт? <a href="login.php" class="link">Войти</a>
    </p>
</div>
</body>
</html>