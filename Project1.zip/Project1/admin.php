<?php
require_once 'config.php';
require_once 'functions.php';

requireAdmin();

$tab = $_GET['tab'] ?? 'users';
$action = $_GET['action'] ?? 'list';
$editUserId = (int)($_GET['id'] ?? 0);

$message = $_SESSION['flash_msg'] ?? '';
$messageType = $_SESSION['flash_type'] ?? 'info';
unset($_SESSION['flash_msg'], $_SESSION['flash_type']);

$errors = [];
$myRole = $_SESSION['role'];

// === ОБРАБОТКА POST-ЗАПРОСОВ ===
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formAction = $_POST['form_action'] ?? '';
    $adminId = (int)$_SESSION['user_id'];
    mysqli_query($connection, "SET @admin_id = $adminId");

    // --- ДОБАВЛЕНИЕ ---
    if ($formAction === 'add') {
        $login      = trim($_POST['login']       ?? '');
        $password   = $_POST['password']         ?? '';
        $firstName  = trim($_POST['first_name']  ?? '');
        $lastName   = trim($_POST['last_name']   ?? '');
        $middleName = trim($_POST['middle_name'] ?? '');
        $email      = trim($_POST['email']       ?? '');
        $birthday   = trim($_POST['birthday']    ?? '');
        $role       = $_POST['role']             ?? 'user';

        if ($role === 'sysadmin' && $myRole !== 'sysadmin') {
            $errors['role'] = 'Только Sysadmin может создавать Sysadmin';
            $role = 'user';
        }

        if ($e = validateLogin($login))          $errors['login']       = $e;
        if ($e = validatePassword($password))    $errors['password']    = $e;
        if ($e = validateName($firstName, 'Имя'))       $errors['first_name']  = $e;
        if ($e = validateName($lastName, 'Фамилия'))    $errors['last_name']   = $e;
        if ($e = validateName($middleName, 'Отчество')) $errors['middle_name'] = $e;
        if ($e = validateEmail($email))          $errors['email']       = $e;
        if ($e = validateBirthday($birthday))    $errors['birthday']    = $e;

        if (empty($errors)) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($connection, 'CALL sp_admin_add_user(?, ?, ?, ?, ?, ?, ?, ?, @uid, @msg)');
            mysqli_stmt_bind_param($stmt, 'ssssssss', $login, $hash, $firstName, $lastName, $middleName, $email, $birthday, $role);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            while (mysqli_more_results($connection) && mysqli_next_result($connection)) {}
            $row = mysqli_fetch_assoc(mysqli_query($connection, 'SELECT @uid AS uid, @msg AS msg'));

            if (!empty($row['uid'])) {
                $_SESSION['flash_msg'] = 'Пользователь успешно добавлен';
                $_SESSION['flash_type'] = 'success';
                header('Location: admin.php?tab=users'); exit;
            } else {
                $message = $row['msg'] ?? 'Ошибка добавления';
                $messageType = 'error';
                $action = 'add';
            }
        } else {
            $message = 'Исправьте ошибки в форме';
            $messageType = 'error';
            $action = 'add';
        }
    }

    // --- РЕДАКТИРОВАНИЕ ---
    if ($formAction === 'edit') {
        $id         = (int)($_POST['id'] ?? 0);
        $firstName  = trim($_POST['first_name']  ?? '');
        $lastName   = trim($_POST['last_name']   ?? '');
        $middleName = trim($_POST['middle_name'] ?? '');
        $email      = trim($_POST['email']       ?? '');
        $birthday   = trim($_POST['birthday']    ?? '');
        $role       = $_POST['role']             ?? 'user';

        $stmt = mysqli_prepare($connection, 'SELECT role FROM users WHERE id = ?');
        mysqli_stmt_bind_param($stmt, 'i', $id);
        mysqli_stmt_execute($stmt);
        $targetRole = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['role'] ?? '';
        mysqli_stmt_close($stmt);

        if ($targetRole === 'sysadmin' && $myRole !== 'sysadmin') {
            $errors['general'] = 'Вы не можете редактировать супер-администратора';
        } elseif ($role === 'sysadmin' && $myRole !== 'sysadmin') {
            $errors['role'] = 'Только Sysadmin может назначать роль Sysadmin';
        }

        if ($e = validateName($firstName, 'Имя'))       $errors['first_name']  = $e;
        if ($e = validateName($lastName, 'Фамилия'))    $errors['last_name']   = $e;
        if ($e = validateName($middleName, 'Отчество')) $errors['middle_name'] = $e;
        if ($e = validateEmail($email))          $errors['email']       = $e;
        if ($e = validateBirthday($birthday))    $errors['birthday']    = $e;

        if (empty($errors)) {
            $stmt = mysqli_prepare($connection, 'CALL sp_admin_update_user(?, ?, ?, ?, ?, ?, ?, @msg)');
            mysqli_stmt_bind_param($stmt, 'issssss', $id, $firstName, $lastName, $middleName, $email, $birthday, $role);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            while (mysqli_more_results($connection) && mysqli_next_result($connection)) {}
            $row = mysqli_fetch_assoc(mysqli_query($connection, 'SELECT @msg AS msg'));

            if (strpos($row['msg'], 'OK') === 0) {
                $_SESSION['flash_msg'] = 'Данные пользователя обновлены';
                $_SESSION['flash_type'] = 'success';
                header('Location: admin.php?tab=users'); exit;
            } else {
                $message = $row['msg'];
                $messageType = 'error';
                $action = 'edit';
                $editUserId = $id;
            }
        } else {
            $message = $errors['general'] ?? 'Исправьте ошибки в форме';
            $messageType = 'error';
            $action = 'edit';
            $editUserId = $id;
        }
    }

    // --- МАССОВАЯ БЛОКИРОВКА ---
    if ($formAction === 'bulk_block' || $formAction === 'bulk_unblock') {
        $ids = $_POST['selected_ids'] ?? [];
        if (!empty($ids)) {
            $idsStr = implode(',', array_map('intval', $ids));
            $blockVal = $formAction === 'bulk_block' ? 1 : 0;
            $stmt = mysqli_prepare($connection, 'CALL sp_admin_bulk_block(?, ?, @msg)');
            mysqli_stmt_bind_param($stmt, 'si', $idsStr, $blockVal);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            $_SESSION['flash_msg'] = "Статус изменен для " . count($ids) . " польз.";
            $_SESSION['flash_type'] = 'success';
        }
        header("Location: admin.php?tab=users"); exit;
    }

    // --- УДАЛЕНИЕ ---
    if ($formAction === 'delete') {
        $id = (int)$_POST['id'];
        $stmt = mysqli_prepare($connection, 'SELECT role FROM users WHERE id = ?');
        mysqli_stmt_bind_param($stmt, 'i', $id);
        mysqli_stmt_execute($stmt);
        $targetRole = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['role'] ?? '';
        mysqli_stmt_close($stmt);

        if ($targetRole === 'sysadmin' && $myRole !== 'sysadmin') {
            $_SESSION['flash_msg'] = 'Ошибка: только Sysadmin может удалить другого Sysadmin';
            $_SESSION['flash_type'] = 'error';
        } else {
            $stmt = mysqli_prepare($connection, 'CALL sp_admin_delete_user(?, @msg)');
            mysqli_stmt_bind_param($stmt, 'i', $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            $_SESSION['flash_msg'] = 'Пользователь удален';
            $_SESSION['flash_type'] = 'success';
        }
        header("Location: admin.php?tab=users"); exit;
    }
    
    // --- УДАЛЕНИЕ ЗАМЕТКИ ---
    if ($formAction === 'delete_note') {
        $noteId = (int)$_POST['note_id'];
        
        $stmt = mysqli_prepare($connection, 'DELETE FROM notes WHERE id = ?');
        mysqli_stmt_bind_param($stmt, 'i', $noteId);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        
        $_SESSION['flash_msg'] = 'Заметка удалена';
        $_SESSION['flash_type'] = 'success';
        header("Location: admin.php?tab=users&action=notes&id=" . (int)$_POST['user_id']); 
        exit;
    }
    
    // --- СБРОС ПАРОЛЯ ---
    if ($formAction === 'reset_password') {
        $id = (int)$_POST['id'];
        $newHash = password_hash('12345678', PASSWORD_DEFAULT);
        
        $stmt = mysqli_prepare($connection, 'UPDATE users SET password = ? WHERE id = ?');
        mysqli_stmt_bind_param($stmt, 'si', $newHash, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        
        $_SESSION['flash_msg'] = 'Пароль сброшен на 12345678';
        $_SESSION['flash_type'] = 'success';
        header("Location: admin.php?tab=users"); exit;
    }
    
    // --- БЛОКИРОВКА ОДНОГО ---
    if ($formAction === 'toggle_block') {
        $id = (int)$_POST['id'];
        $stmt = mysqli_prepare($connection, 'SELECT role FROM users WHERE id = ?');
        mysqli_stmt_bind_param($stmt, 'i', $id);
        mysqli_stmt_execute($stmt);
        $targetRole = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['role'] ?? '';
        mysqli_stmt_close($stmt);

        if ($targetRole === 'sysadmin' && $myRole !== 'sysadmin') {
            $_SESSION['flash_msg'] = 'Ошибка: нельзя заблокировать Sysadmin';
            $_SESSION['flash_type'] = 'error';
        } else {
            $stmt = mysqli_prepare($connection, 'CALL sp_admin_toggle_block(?, @msg)');
            mysqli_stmt_bind_param($stmt, 'i', $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            $_SESSION['flash_msg'] = 'Статус блокировки изменен';
            $_SESSION['flash_type'] = 'success';
        }
        header("Location: admin.php?tab=users"); exit;
    }
}

// === СБОР ДАННЫХ ДЛЯ ОТОБРАЖЕНИЯ ===
$users = [];
$stats = ['total' => 0, 'active' => 0, 'blocked' => 0, 'sysadmin' => 0, 'admin' => 0, 'user' => 0];
$editUser = null;
$userNotes = [];

if ($tab === 'users') {
    // 1. Если открываем редактирование
    if ($action === 'edit' && $editUserId > 0) {
        $stmt = mysqli_prepare($connection, 'SELECT * FROM users WHERE id = ? LIMIT 1');
        mysqli_stmt_bind_param($stmt, 'i', $editUserId);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        $editUser = mysqli_fetch_assoc($res);
        mysqli_stmt_close($stmt);
    }
    
    // 2. Если открываем заметки
    if ($action === 'notes' && $editUserId > 0) {
        $stmt = mysqli_prepare($connection, 'SELECT * FROM notes WHERE user_id = ? ORDER BY created_at DESC');
        mysqli_stmt_bind_param($stmt, 'i', $editUserId);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        while ($n = mysqli_fetch_assoc($res)) $userNotes[] = $n;
        mysqli_stmt_close($stmt);
    }

    $search = trim($_GET['search'] ?? '');
    $roleFilter = $_GET['role'] ?? '';
    $statusFilter = $_GET['status'] ?? '';

    $sql = "SELECT * FROM users WHERE 1=1";
    if ($search) {
        $s = mysqli_real_escape_string($connection, $search);
        $sql .= " AND (login LIKE '%$s%' OR first_name LIKE '%$s%' OR last_name LIKE '%$s%' OR email LIKE '%$s%')";
    }
    if ($roleFilter) {
        $r = mysqli_real_escape_string($connection, $roleFilter);
        $sql .= " AND role = '$r'";
    }
    if ($statusFilter === 'blocked') $sql .= " AND is_blocked = 1";
    if ($statusFilter === 'active') $sql .= " AND is_blocked = 0";
    
    $sql .= " ORDER BY id DESC";
    $res = mysqli_query($connection, $sql);
    while ($row = mysqli_fetch_assoc($res)) {
        $users[] = $row;
        if ($search === '' && $roleFilter === '' && $statusFilter === '') {
            $stats['total']++;
            if ($row['is_blocked']) $stats['blocked']++; else $stats['active']++;
            if ($row['role'] === 'sysadmin') $stats['sysadmin']++;
            elseif ($row['role'] === 'admin') $stats['admin']++;
            else $stats['user']++;
        }
    }
    if ($search || $roleFilter || $statusFilter) {
        $r2 = mysqli_query($connection, "SELECT COUNT(*) c, SUM(is_blocked=0) act, SUM(is_blocked=1) blk, SUM(role='sysadmin') sa, SUM(role='admin') a, SUM(role='user') u FROM users");
        $st = mysqli_fetch_assoc($r2);
        $stats = ['total'=>$st['c'], 'active'=>$st['act'], 'blocked'=>$st['blk'], 'sysadmin'=>$st['sa'], 'admin'=>$st['a'], 'user'=>$st['u']];
    }
}

$audit = [];
if ($tab === 'audit') {
    $res = mysqli_query($connection, "SELECT l.*, u.login, u.first_name, u.last_name FROM users_log l LEFT JOIN users u ON l.user_id = u.id ORDER BY l.id DESC LIMIT 100");
    while ($row = mysqli_fetch_assoc($res)) $audit[] = $row;
}

$tables = [];
$dbStats = ['tables' => 0, 'size_mb' => 0, 'rows' => 0];
if ($tab === 'db') {
    $res = mysqli_query($connection, "SHOW TABLE STATUS");
    while ($row = mysqli_fetch_assoc($res)) {
        $tables[] = $row;
        $dbStats['tables']++;
        $dbStats['size_mb'] += ($row['Data_length'] + $row['Index_length']);
        $dbStats['rows'] += $row['Rows'];
    }
    $dbStats['size_mb'] = round($dbStats['size_mb'] / (1024 * 1024), 2);
}

$sysInfo = null;
if ($tab === 'sysinfo' && file_exists('selenium_report.json')) {
    $sysInfo = json_decode(file_get_contents('selenium_report.json'), true);
}

$statusNames = ['BLOCKED' => 'Блокировка', 'UNBLOCKED' => 'Разблокировка', 'ROLE_CHANGE' => 'Смена роли', 'PASSWORD_CHANGE' => 'Смена пароля'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Админ-панель</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
        .top-bar h1 { margin: 0; border: none; padding: 0; font-size: 22px; display: flex; align-items: center; gap: 10px; }
        .top-actions { display: flex; gap: 10px; }
        .tabs { display: flex; gap: 8px; margin-bottom: 24px; background: var(--bg-hover); padding: 6px; border-radius: 10px; border: 1px solid var(--border); width: fit-content; }
        .tab-item { padding: 8px 24px; font-size: 14.5px; font-weight: 500; color: var(--text-soft); text-decoration: none; border-radius: 8px; transition: all 0.2s; border: 1px solid transparent; }
        .tab-item:hover { color: var(--text-main); background: rgba(255, 255, 255, 0.5); }
        .tab-item.active { background: #ffffff; color: var(--accent); border-color: var(--border); box-shadow: 0 2px 4px rgba(0,0,0,0.05); font-weight: 600; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: var(--md-surface-2); padding: 16px; border-radius: var(--r-md); box-shadow: var(--el-1); }
        .stat-value { font-size: 24px; font-weight: 600; color: var(--md-on-surface); margin-bottom: 4px; }
        .stat-label { font-size: 12px; color: var(--md-on-surface-var); text-transform: uppercase; letter-spacing: 0.05em; }
        
        .filters { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; align-items: center; background: var(--md-surface-2); padding: 16px; border-radius: var(--r-md); }
        .filters input, .filters select { margin-bottom: 0; padding: 8px 12px; flex: 1; min-width: 150px; }
        .bulk-bar { display: flex; align-items: center; gap: 12px; background: rgba(208, 188, 255, 0.1); border: 1px solid var(--md-primary); padding: 12px 16px; border-radius: var(--r-sm); margin-bottom: 16px; }
        
        .role-badge { padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: 600; }
        .role-sysadmin { background: #a371f722; color: #a371f7; border: 1px solid #a371f755; }
        .role-admin { background: #d2992222; color: #d29922; border: 1px solid #d2992255; }
        .role-user { background: #58a6ff22; color: #58a6ff; border: 1px solid #58a6ff55; }
        
        .action-badge { padding: 2px 8px; border-radius: 4px; font-size: 12px; }
        .act-block { background: #f8514922; color: #f85149; }
        .act-unblock { background: #3fb95022; color: #3fb950; }
        .act-role { background: #d2992222; color: #d29922; }
        
        .act-btn { background: transparent; border: none; cursor: pointer; padding: 6px; border-radius: 4px; color: var(--md-on-surface-var); display: inline-flex; align-items: center; justify-content: center; transition: 0.2s; }
        .act-btn:hover { background: rgba(255,255,255,0.1); color: var(--md-on-surface); }
        .act-btn.danger:hover { background: #da363355; color: #f85149; }
        .act-btn.success { color: #3fb950; }
        .table-responsive { overflow-x: auto; border-radius: var(--r-md); border: 1px solid var(--md-outline-var); }
        table { margin: 0; box-shadow: none; border-radius: 0; }
    </style>
</head>
<body>
<div class="container wide" style="max-width: 1200px;">
    
    <div class="top-bar">
        <h1>🛡 Админ-панель — <?= $tab === 'users' ? ($action === 'add' ? 'Новый пользователь' : ($action === 'edit' ? 'Редактирование' : ($action === 'notes' ? 'Заметки пользователя' : 'Пользователи'))) : ($tab === 'audit' ? 'Журнал аудита' : ($tab === 'sysinfo' ? 'Мониторинг' : 'Таблицы БД')) ?></h1>
        <div class="top-actions">
            <a href="index.php" class="btn btn-secondary">← В панель</a>
            <a href="logout.php" class="btn btn-danger">Выйти</a>
        </div>
    </div>

    <div class="tabs">
        <a href="admin.php?tab=users" class="tab-item <?= $tab === 'users' ? 'active' : '' ?>">Пользователи</a>
        <a href="admin.php?tab=audit" class="tab-item <?= $tab === 'audit' ? 'active' : '' ?>">Аудит</a>
        <a href="admin.php?tab=db" class="tab-item <?= $tab === 'db' ? 'active' : '' ?>">Таблицы БД</a>
        <a href="admin.php?tab=sysinfo" class="tab-item <?= $tab === 'sysinfo' ? 'active' : '' ?>">Мониторинг ПК</a>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?>" style="padding: 12px; margin-bottom: 20px; border-radius: 8px; display: flex; gap: 10px; align-items: center; background: <?= $messageType==='success'?'#3fb95022':'#f8514922' ?>; color: <?= $messageType==='success'?'#3fb950':'#f85149' ?>; border: 1px solid currentColor;">
            <span><?= $messageType === 'success' ? '✅' : '❌' ?></span>
            <div><?= e($message) ?></div>
        </div>
    <?php endif; ?>

    <?php if ($tab === 'users'): ?>
        
        <?php if ($action === 'notes'): ?>
            <!-- ПРОСМОТР ЗАМЕТОК ПОЛЬЗОВАТЕЛЯ -->
            <div style="margin-bottom: 20px;">
                <a href="admin.php?tab=users" class="btn btn-secondary">← Назад к списку</a>
            </div>
            
            <h2>📝 Заметки пользователя (ID: <?= $editUserId ?>)</h2>
            
            <?php if (empty($userNotes)): ?>
                <div class="alert alert-info" style="background: #eff6ff; color: #1d4ed8; border: 1px solid #bfdbfe; padding: 12px; border-radius: 8px;">
                    У этого пользователя нет заметок.
                </div>
            <?php else: ?>
                <?php foreach ($userNotes as $note): ?>
                    <div style="background: #fff; border: 1px solid var(--border); border-radius: 8px; padding: 16px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: flex-start; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
                        <div>
                            <h3 style="margin: 0 0 8px 0; font-size: 16px; color: #1e293b;">
                                <?= e($note['title']) ?>
                                <span style="font-size: 12px; color: #64748b; font-weight: normal; margin-left: 8px;">от <?= date('d.m.Y', strtotime($note['created_at'])) ?></span>
                            </h3>
                            <p style="margin: 0; font-size: 14px; color: #475569;"><?= nl2br(e($note['content'])) ?></p>
                        </div>
                        
                        <form method="POST" onsubmit="return confirm('Удалить эту заметку?');">
                            <input type="hidden" name="form_action" value="delete_note">
                            <input type="hidden" name="note_id" value="<?= $note['id'] ?>">
                            <input type="hidden" name="user_id" value="<?= $editUserId ?>">
                            <button type="submit" class="btn btn-danger btn-sm">🗑️ Удалить</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

        <?php elseif ($action === 'add'): ?>
            <!-- ФОРМА ДОБАВЛЕНИЯ -->
            <div style="background: var(--md-surface-2); padding: 24px; border-radius: var(--r-md); max-width: 600px; margin: 0 auto;">
                <h2>➕ Добавить пользователя</h2>
                <form method="post">
                    <input type="hidden" name="form_action" value="add">
                    <label>Имя</label><input type="text" name="first_name" value="<?= e($_POST['first_name'] ?? '') ?>" required>
                    <?php if (!empty($errors['first_name'])): ?><span class="field-error"><?= e($errors['first_name']) ?></span><?php endif; ?>
                    <label>Фамилия</label><input type="text" name="last_name" value="<?= e($_POST['last_name'] ?? '') ?>" required>
                    <?php if (!empty($errors['last_name'])): ?><span class="field-error"><?= e($errors['last_name']) ?></span><?php endif; ?>
                    <label>Отчество</label><input type="text" name="middle_name" value="<?= e($_POST['middle_name'] ?? '') ?>" required>
                    <?php if (!empty($errors['middle_name'])): ?><span class="field-error"><?= e($errors['middle_name']) ?></span><?php endif; ?>
                    <label>Логин</label><input type="text" name="login" value="<?= e($_POST['login'] ?? '') ?>" required>
                    <?php if (!empty($errors['login'])): ?><span class="field-error"><?= e($errors['login']) ?></span><?php endif; ?>
                    <label>Email</label><input type="text" name="email" value="<?= e($_POST['email'] ?? '') ?>" required>
                    <?php if (!empty($errors['email'])): ?><span class="field-error"><?= e($errors['email']) ?></span><?php endif; ?>
                    <label>Дата рождения</label><input type="date" name="birthday" value="<?= e($_POST['birthday'] ?? '') ?>" required>
                    <?php if (!empty($errors['birthday'])): ?><span class="field-error"><?= e($errors['birthday']) ?></span><?php endif; ?>
                    <label>Пароль</label><input type="password" name="password" required>
                    <?php if (!empty($errors['password'])): ?><span class="field-error"><?= e($errors['password']) ?></span><?php endif; ?>
                    <label>Роль</label>
                    <select name="role">
                        <option value="user">Пользователь</option>
                        <option value="admin">Администратор</option>
                        <?php if ($myRole === 'sysadmin'): ?>
                            <option value="sysadmin">Sysadmin</option>
                        <?php endif; ?>
                    </select>
                    <?php if (!empty($errors['role'])): ?><span class="field-error"><?= e($errors['role']) ?></span><?php endif; ?>
                    <div style="margin-top: 20px; display: flex; gap: 10px;">
                        <button type="submit" class="btn btn-primary">💾 Сохранить</button>
                        <a href="admin.php?tab=users" class="btn btn-secondary">Отмена</a>
                    </div>
                </form>
            </div>

        <?php elseif ($action === 'edit' && $editUser): ?>
            <!-- ФОРМА РЕДАКТИРОВАНИЯ -->
            <div style="background: var(--md-surface-2); padding: 24px; border-radius: var(--r-md); max-width: 600px; margin: 0 auto;">
                <h2>✏️ Редактировать: <?= e($editUser['login']) ?></h2>
                <form method="post">
                    <input type="hidden" name="form_action" value="edit">
                    <input type="hidden" name="id" value="<?= (int)$editUser['id'] ?>">
                    
                    <label>Имя</label><input type="text" name="first_name" value="<?= e($_POST['first_name'] ?? $editUser['first_name']) ?>" required>
                    <label>Фамилия</label><input type="text" name="last_name" value="<?= e($_POST['last_name'] ?? $editUser['last_name']) ?>" required>
                    <label>Отчество</label><input type="text" name="middle_name" value="<?= e($_POST['middle_name'] ?? $editUser['middle_name']) ?>" required>
                    <label>Email</label><input type="text" name="email" value="<?= e($_POST['email'] ?? $editUser['email']) ?>" required>
                    <label>Дата рождения</label><input type="date" name="birthday" value="<?= e($_POST['birthday'] ?? $editUser['birthday']) ?>" required>
                    
                    <label>Роль</label>
                    <select name="role" <?= $editUser['role'] === 'sysadmin' && $myRole !== 'sysadmin' ? 'disabled' : '' ?>>
                        <option value="user" <?= $editUser['role'] === 'user' ? 'selected' : '' ?>>Пользователь</option>
                        <option value="admin" <?= $editUser['role'] === 'admin' ? 'selected' : '' ?>>Администратор</option>
                        <?php if ($myRole === 'sysadmin'): ?>
                            <option value="sysadmin" <?= $editUser['role'] === 'sysadmin' ? 'selected' : '' ?>>Sysadmin</option>
                        <?php endif; ?>
                    </select>
                    
                    <div style="margin-top: 20px; display: flex; gap: 10px;">
                        <button type="submit" class="btn btn-primary">💾 Сохранить</button>
                        <a href="admin.php?tab=users" class="btn btn-secondary">Отмена</a>
                    </div>
                </form>
            </div>
            
        <?php else: ?>
            <!-- СПИСОК ПОЛЬЗОВАТЕЛЕЙ -->
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-value"><?= $stats['total'] ?></div><div class="stat-label">Всего</div></div>
                <div class="stat-card"><div class="stat-value"><?= $stats['active'] ?></div><div class="stat-label">Активных</div></div>
                <div class="stat-card"><div class="stat-value"><?= $stats['blocked'] ?></div><div class="stat-label">Заблокировано</div></div>
                <div class="stat-card"><div class="stat-value"><?= $stats['sysadmin'] ?></div><div class="stat-label">Sysadmin</div></div>
                <div class="stat-card"><div class="stat-value"><?= $stats['admin'] ?></div><div class="stat-label">Admin</div></div>
                <div class="stat-card"><div class="stat-value"><?= $stats['user'] ?></div><div class="stat-label">User</div></div>
            </div>

            <form method="GET" class="filters">
                <input type="hidden" name="tab" value="users">
                <input type="text" name="search" value="<?= e($_GET['search'] ?? '') ?>" placeholder="Поиск по ФИО, логину, email...">
                <select name="role">
                    <option value="">Все роли</option>
                    <option value="sysadmin" <?= ($_GET['role']??'')==='sysadmin'?'selected':'' ?>>Sysadmin</option>
                    <option value="admin" <?= ($_GET['role']??'')==='admin'?'selected':'' ?>>Admin</option>
                    <option value="user" <?= ($_GET['role']??'')==='user'?'selected':'' ?>>User</option>
                </select>
                <select name="status">
                    <option value="">Все статусы</option>
                    <option value="active" <?= ($_GET['status']??'')==='active'?'selected':'' ?>>Активные</option>
                    <option value="blocked" <?= ($_GET['status']??'')==='blocked'?'selected':'' ?>>Заблокированные</option>
                </select>
                <button type="submit" class="btn btn-primary">Фильтр</button>
                <a href="admin.php?tab=users" class="btn btn-secondary">Сбросить</a>
                <a href="export_users.php?search=<?= e($_GET['search'] ?? '') ?>&role=<?= e($_GET['role'] ?? '') ?>&status=<?= e($_GET['status'] ?? '') ?>" class="btn btn-secondary" style="margin-left: auto;">📥 Экспорт в JSON</a>
                <a href="admin.php?tab=users&action=add" class="btn btn-primary" style="background: #238636; border-color: #238636;">+ Создать пользователя</a>
            </form>

            <form method="POST" id="bulkForm">
                <div class="bulk-bar">
                    <span>Выбрано: <strong id="selCount">0</strong></span>
                    <select name="bulk_action" id="bulkActionSelect" style="width: 200px; margin-bottom: 0;">
                        <option value="">— Действие —</option>
                        <option value="bulk_block">Заблокировать</option>
                        <option value="bulk_unblock">Разблокировать</option>
                    </select>
                    <button type="submit" class="btn btn-secondary" onclick="document.getElementById('formAction').value = document.getElementById('bulkActionSelect').value;">Применить</button>
                    <input type="hidden" name="form_action" id="formAction">
                </div>

                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;"><input type="checkbox" id="selectAll" style="accent-color: var(--md-primary);"></th>
                                <th>ID</th>
                                <th>ФИО</th>
                                <th>Логин</th>
                                <th>Email</th>
                                <th>Роль</th>
                                <th>Статус</th>
                                <th style="text-align: right;">Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $u): ?>
                                <?php 
                                    $isBlk = (int)($u['is_blocked'] ?? 0); 
                                    $canManage = ($myRole === 'sysadmin') || ($u['role'] !== 'sysadmin');
                                ?>
                                <tr>
                                    <td style="text-align: center;">
                                        <?php if ($canManage): ?>
                                            <input type="checkbox" name="selected_ids[]" value="<?= $u['id'] ?>" class="user-cb" style="accent-color: var(--md-primary);">
                                        <?php endif; ?>
                                    </td>
                                    <td><?= $u['id'] ?></td>
                                    <td><?= e($u['last_name'] . ' ' . $u['first_name']) ?></td>
                                    <td><?= e($u['login']) ?></td>
                                    <td><a href="mailto:<?= e($u['email']) ?>"><?= e($u['email']) ?></a></td>
                                    <td><span class="role-badge role-<?= $u['role'] ?>"><?= $u['role'] ?></span></td>
                                    <td>
                                        <?php if ($isBlk): ?>
                                            <span class="badge badge-blocked">заблокирован</span>
                                        <?php else: ?>
                                            <span class="badge badge-active">активен</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align: right; white-space: nowrap;">
                                        <?php if ($canManage): ?>
                                            <a href="admin.php?tab=users&action=notes&id=<?= $u['id'] ?>" class="act-btn" title="Заметки пользователя">📝</a>
                                            <a href="admin.php?tab=users&action=edit&id=<?= $u['id'] ?>" class="act-btn" title="Редактировать">✏️</a>
                                            <button type="button" class="act-btn <?= $isBlk ? 'success' : '' ?>" onclick="singleAction('toggle_block', <?= $u['id'] ?>)" title="<?= $isBlk ? 'Разблокировать' : 'Заблокировать' ?>">
                                                <?= $isBlk ? '🟢' : '⛔' ?>
                                            </button>
                                            <button type="button" class="act-btn" onclick="singleAction('reset_password', <?= $u['id'] ?>)" title="Сбросить пароль на 12345678">🔑</button>
                                            <button type="button" class="act-btn danger" onclick="singleAction('delete', <?= $u['id'] ?>)" title="Удалить">🗑️</button>
                                        <?php else: ?>
                                            <span style="font-size: 12px; color: var(--md-on-surface-var);">🔒 Защищён</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </form>
            
            <form method="POST" id="singleForm" style="display:none;">
                <input type="hidden" name="form_action" id="singleAction">
                <input type="hidden" name="id" id="singleId">
            </form>
        <?php endif; ?>

    <?php elseif ($tab === 'audit'): ?>
        <!-- БЛОК АУДИТА -->
        <div class="stats-grid">
            <div class="stat-card"><div class="stat-value"><?= count($audit) ?></div><div class="stat-label">Записей аудита</div></div>
            <div class="stat-card"><div class="stat-value">3</div><div class="stat-label">Смен ролей</div></div>
            <div class="stat-card"><div class="stat-value">3</div><div class="stat-label">Блокировок</div></div>
            <div class="stat-card"><div class="stat-value">4</div><div class="stat-label">Разблокировок</div></div>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr><th>ID</th><th>Когда</th><th>Пользователь</th><th>Действие</th><th>Было</th><th>Стало</th><th>Кто изменил</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($audit as $log): ?>
                        <tr>
                            <td><?= $log['id'] ?></td>
                            <td><?= date('Y-m-d H:i:s', strtotime($log['created_at'])) ?></td>
                            <td><?= e($log['last_name'] . ' ' . $log['first_name'] . ' (' . $log['login'] . ')') ?></td>
                            <td>
                                <?php 
                                    $actClass = 'act-role';
                                    if ($log['action'] === 'BLOCKED') $actClass = 'act-block';
                                    if ($log['action'] === 'UNBLOCKED') $actClass = 'act-unblock';
                                ?>
                                <span class="action-badge <?= $actClass ?>"><?= $statusNames[$log['action']] ?? $log['action'] ?></span>
                            </td>
                            <td><?= e($log['old_value'] ?? '—') ?></td>
                            <td><?= e($log['new_value'] ?? '—') ?></td>
                            <td>admin@localhost</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php elseif ($tab === 'db'): ?>
        <!-- БЛОК БАЗЫ ДАННЫХ -->
        <div class="stats-grid">
            <div class="stat-card"><div class="stat-value"><?= $dbStats['tables'] ?></div><div class="stat-label">Всего таблиц</div></div>
            <div class="stat-card"><div class="stat-value"><?= $dbStats['size_mb'] ?> МБ</div><div class="stat-label">Размер БД</div></div>
            <div class="stat-card"><div class="stat-value"><?= $dbStats['rows'] ?></div><div class="stat-label">Всего записей</div></div>
            <div class="stat-card"><div class="stat-value" style="font-size: 16px; margin-top: 6px;">Vysochenko_bd</div><div class="stat-label">База данных</div></div>
        </div>
        <div style="background: var(--md-surface-2); padding: 16px; border-radius: var(--r-md); margin-bottom: 20px; display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
    <a href="backup.php" class="btn btn-primary" style="background: #238636; border-color: #238636;">
        💾 Создать бэкап БД
    </a>
    <button type="button" class="btn btn-secondary" onclick="loadBackups()">
        📂 Список бэкапов на сервере
    </button>
    <span style="color: var(--md-on-surface-var); font-size: 13px;">
        Хранится последних: 10 | Формат: .sql.gz (структура + данные + процедуры + триггеры)
    </span>
</div>

<div id="backupsList" style="display:none; background: var(--md-surface-2); padding: 16px; border-radius: var(--r-md); margin-bottom: 20px;"></div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr><th>Таблица</th><th>Строк</th><th>Размер</th><th>Создана</th><th>Изменена</th><th>Статус</th><th style="text-align: right;">Действия</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($tables as $t): ?>
                        <?php 
                            $isProtected = in_array($t['Name'], ['users', 'users_log']);
                            $sizeKb = round(($t['Data_length'] + $t['Index_length']) / 1024, 1);
                            $statusText = $isProtected ? 'защищена' : 'обычная';
                            $statusColor = $isProtected ? '#f8514922' : '#3fb95022';
                            $statusTextColor = $isProtected ? '#f85149' : '#3fb950';
                        ?>
                        <tr>
                            <td><?= e($t['Name']) ?></td>
                            <td><?= $t['Rows'] ?></td>
                            <td><?= $sizeKb ?> КБ</td>
                            <td><?= date('Y-m-d H:i:s', strtotime($t['Create_time'])) ?></td>
                            <td><?= $t['Update_time'] ? date('Y-m-d H:i:s', strtotime($t['Update_time'])) : '—' ?></td>
                            <td>
                                <span style="background: <?= $statusColor ?>; color: <?= $statusTextColor ?>; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;"><?= $statusText ?></span>
                            </td>
                            <td style="text-align: right;">
                                <button type="button" class="act-btn" title="Просмотр">👁️</button>
                                <?php if (!$isProtected): ?><button type="button" class="act-btn danger" title="Удалить">🗑️</button><?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php elseif ($tab === 'sysinfo'): ?>
        <!-- БЛОК МОНИТОРИНГА ПК -->
        <h2>🖥️ Мониторинг системы (Selenium)</h2>
        
        <?php if (!$sysInfo): ?>
            <div class="alert alert-error" style="margin-bottom: 20px; background: #fef2f2; color: #b91c1c; border: 1px solid #fca5a5; padding: 12px; border-radius: 8px;">
                ⚠️ Файл <code>selenium_report.json</code> не найден. Запустите скрипт <code>selenium_test.py</code> в консоли, чтобы собрать данные.
            </div>
        <?php else: ?>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value" style="font-size: 16px; margin-top: 6px;"><?= e($sysInfo['system_stats']['os']) ?></div>
                    <div class="stat-label">Операционная система</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?= e($sysInfo['system_stats']['cpu_percent']) ?>%</div>
                    <div class="stat-label">Нагрузка на ЦП</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?= e($sysInfo['system_stats']['ram_total_gb']) ?> ГБ</div>
                    <div class="stat-label">ОЗУ (занято <?= e($sysInfo['system_stats']['ram_percent']) ?>%)</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?= e($sysInfo['system_stats']['disk_free_gb']) ?> ГБ</div>
                    <div class="stat-label">Свободно на диске</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" style="<?= !is_numeric($sysInfo['system_stats']['internet_speed_mbps']) ? 'font-size: 16px; margin-top: 6px;' : '' ?>">
                        <?= e($sysInfo['system_stats']['internet_speed_mbps']) ?> 
                        <?= is_numeric($sysInfo['system_stats']['internet_speed_mbps']) ? 'Мбит/с' : '' ?>
                    </div>
                    <div class="stat-label">Скорость интернета</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" style="color: <?= $sysInfo['login_status'] === 'success' ? '#10b981' : '#ef4444' ?>">
                        <?= $sysInfo['login_status'] === 'success' ? 'Успешно' : 'Ошибка' ?>
                    </div>
                    <div class="stat-label">Тест авторизации (<?= e($sysInfo['user_role']) ?>)</div>
                </div>
            </div>
            
            <div class="alert alert-info" style="margin-top: 20px; background: #eff6ff; color: #1d4ed8; border: 1px solid #bfdbfe; padding: 12px; border-radius: 8px;">
                <strong>ℹ️ Данные получены автоматически</strong> Python-скриптом с использованием Selenium.
                Последнее обновление: <?= date('d.m.Y H:i:s', filemtime('selenium_report.json')) ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<script>
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('change', function() {
            document.querySelectorAll('.user-cb').forEach(cb => cb.checked = this.checked);
            updateCount();
        });
        document.querySelectorAll('.user-cb').forEach(cb => cb.addEventListener('change', updateCount));
    }
    function updateCount() {
        const count = document.querySelectorAll('.user-cb:checked').length;
        const el = document.getElementById('selCount');
        if (el) el.textContent = count;
    }
    function singleAction(action, id) {
        if (action === 'delete' && !confirm('Удалить пользователя?')) return;
        if (action === 'toggle_block' && !confirm('Изменить блокировку?')) return;
        if (action === 'reset_password' && !confirm('Сбросить пароль на 12345678?')) return;
        document.getElementById('singleAction').value = action;
        document.getElementById('singleId').value = id;
        document.getElementById('singleForm').submit();
    }
</script>
<script>
function loadBackups() {
    const box = document.getElementById('backupsList');
    if (box.style.display === 'block') { box.style.display = 'none'; return; }
    fetch('backup.php?mode=list')
        .then(r => r.json())
        .then(files => {
            if (!files.length) {
                box.innerHTML = '<p style="color: var(--md-on-surface-var);">Бэкапов на сервере пока нет.</p>';
            } else {
                let html = '<h3 style="margin-top:0;">Сохранённые бэкапы:</h3><table style="width:100%;"><tbody>';
                files.forEach(f => {
                    html += `<tr>
                        <td>${f.name}</td>
                        <td>${f.size}</td>
                        <td>${f.date}</td>
                        <td style="text-align:right;">
                            <a href="backups/${f.name}" class="act-btn" title="Скачать">⬇️</a>
                            <a href="backup.php?mode=delete&file=${encodeURIComponent(f.name)}"
                               class="act-btn danger" title="Удалить"
                               onclick="return confirm('Удалить бэкап ${f.name}?')">🗑️</a>
                        </td>
                    </tr>`;
                });
                html += '</tbody></table>';
                box.innerHTML = html;
            }
            box.style.display = 'block';
        });
}
</script>
</body>
</html>