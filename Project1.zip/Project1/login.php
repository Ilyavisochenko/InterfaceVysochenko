<?php
require_once 'config.php';
require_once 'functions.php';

// Уже авторизован — на главную
if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$MAX_ATTEMPTS = 3;
$maxAttempts  = $MAX_ATTEMPTS;   // для bind_param (нужна переменная, не константа)

$error = '';
$login = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login        = trim($_POST['login']         ?? '');
    $password     = $_POST['password']           ?? '';
    $captchaOrder = trim($_POST['captcha_order'] ?? '');

    if ($login === '' || $password === '') {
        $error = 'Заполните все поля';
    } else {
        // --- ПРОВЕРКА ПАЗЛА ---
        $correct = implode(',', $_SESSION['captcha_puzzle_correct'] ?? []);

        if ($captchaOrder !== $correct) {
            // Пазл собран неверно — инкремент попыток
            $stmt = mysqli_prepare($connection,
                'CALL sp_login_failed(?, ?, @msg, @blocked)');
            mysqli_stmt_bind_param($stmt, 'si', $login, $maxAttempts);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            while (mysqli_more_results($connection) && mysqli_next_result($connection)) {}

            $res = mysqli_query($connection, 'SELECT @msg AS msg, @blocked AS blocked');
            $row = mysqli_fetch_assoc($res);

            $error = $row['msg'] ?? 'Пазл собран неверно';
            unset($_SESSION['captcha_puzzle_correct']);

        } else {
            // --- ПАЗЛ ВЕРНЫЙ — ПРОВЕРЯЕМ ПОЛЬЗОВАТЕЛЯ ---
            $stmt = mysqli_prepare($connection,
                'CALL sp_login_user(?, @uid, @role, @blocked, @msg)');
            mysqli_stmt_bind_param($stmt, 's', $login);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            while (mysqli_more_results($connection) && mysqli_next_result($connection)) {}

            $res = mysqli_query($connection,
                'SELECT @uid AS uid, @role AS role, @blocked AS blocked, @msg AS msg');
            $row = mysqli_fetch_assoc($res);

            if (empty($row['uid'])) {
                // Пользователь не найден — считаем за неудачную попытку
                $stmt = mysqli_prepare($connection,
                    'CALL sp_login_failed(?, ?, @msg, @blocked)');
                mysqli_stmt_bind_param($stmt, 'si', $login, $maxAttempts);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
                while (mysqli_more_results($connection) && mysqli_next_result($connection)) {}

                $res2 = mysqli_query($connection, 'SELECT @msg AS msg');
                $r2 = mysqli_fetch_assoc($res2);

                $error = $r2['msg'] ?? 'Неверный логин или пароль';
                unset($_SESSION['captcha_puzzle_correct']);

            } elseif ((int)$row['blocked'] === 1) {
                // Заблокирован
                $error = 'Вы заблокированы. Обратитесь к администратору';
                unset($_SESSION['captcha_puzzle_correct']);

            } else {
                // Получаем хеш пароля для проверки
                $stmt = mysqli_prepare($connection,
                    'SELECT password, login, first_name, last_name, middle_name, email, role
                     FROM users WHERE id = ? LIMIT 1');
                mysqli_stmt_bind_param($stmt, 'i', $row['uid']);
                mysqli_stmt_execute($stmt);
                $resUser = mysqli_stmt_get_result($stmt);
                $user = mysqli_fetch_assoc($resUser);
                mysqli_stmt_close($stmt);

                if (!$user || !password_verify($password, $user['password'])) {
                    // Неверный пароль — инкремент попыток
                    $stmt = mysqli_prepare($connection,
                        'CALL sp_login_failed(?, ?, @msg, @blocked)');
                    mysqli_stmt_bind_param($stmt, 'si', $login, $maxAttempts);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                    while (mysqli_more_results($connection) && mysqli_next_result($connection)) {}

                    $resFail = mysqli_query($connection, 'SELECT @msg AS msg');
                    $rFail = mysqli_fetch_assoc($resFail);

                    $error = $rFail['msg'] ?? 'Неверный логин или пароль';
                    unset($_SESSION['captcha_puzzle_correct']);

                } else {
                    // --- УСПЕХ ---
                    $stmt = mysqli_prepare($connection, 'CALL sp_login_success(?)');
                    mysqli_stmt_bind_param($stmt, 'i', $row['uid']);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                    while (mysqli_more_results($connection) && mysqli_next_result($connection)) {}

                    $_SESSION['user_id']     = $row['uid'];
                    $_SESSION['login']       = $user['login'];
                    $_SESSION['first_name']  = $user['first_name'];
                    $_SESSION['last_name']   = $user['last_name'];
                    $_SESSION['middle_name'] = $user['middle_name'];
                    $_SESSION['email']       = $user['email'];
                    $_SESSION['role']        = $row['role'];

                    unset($_SESSION['captcha_puzzle_correct']);

                    header('Location: index.php');
                    exit;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .puzzle-wrapper {
            margin: 20px 0;
            padding: 20px;
            background: #f8fafc;
            border: 2px solid #e5e7eb;
            border-radius: 12px;
        }
        .puzzle-title {
            text-align: center;
            margin-bottom: 8px;
            font-weight: 600;
            color: #222;
        }
        .puzzle-instruction {
            text-align: center;
            font-size: 13px;
            color: #6b7280;
            margin-bottom: 15px;
        }
        .puzzle-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 4px;
            max-width: 300px;
            margin: 0 auto;
            background: #fff;
            padding: 6px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.06);
        }
        .puzzle-piece {
            aspect-ratio: 1 / 1;
            cursor: grab;
            border-radius: 6px;
            overflow: hidden;
            background: #f0f0f0;
            transition: all 0.2s ease;
        }
        .puzzle-piece img {
            width: 100%;
            height: 100%;
            display: block;
            pointer-events: none;
            user-select: none;
            object-fit: cover;
        }
        .puzzle-piece:hover { box-shadow: 0 0 0 2px #0085B2; }
        .puzzle-piece.dragging { opacity: 0.4; transform: scale(0.95); cursor: grabbing; }
        .puzzle-piece.drag-over { box-shadow: 0 0 0 3px #0085B2; background: #e6f7ff; }
        .puzzle-refresh {
            display: block;
            margin: 15px auto 0;
            padding: 8px 16px;
            background: #6c757d;
            color: #fff;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
        }
        .puzzle-refresh:hover { background: #5a6268; }
    </style>
</head>
<body>
<div class="container">
    <h1>🔑 Вход в систему</h1>

    <?php if (!empty($_SESSION['flash_success'])): ?>
        <div class="success"><?= e($_SESSION['flash_success']) ?></div>
        <?php unset($_SESSION['flash_success']); ?>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post">
        <label>Логин</label>
        <input type="text" name="login" value="<?= e($login) ?>" required autofocus>

        <label>Пароль</label>
        <input type="password" name="password" required>

        <!-- ===== ПАЗЛ ===== -->
        <div class="puzzle-wrapper">
            <div class="puzzle-title">🧩 Соберите картинку</div>
            <div class="puzzle-instruction">
                Перетащите фрагменты так, чтобы получилось целое изображение
            </div>

            <div class="puzzle-grid" id="puzzleGrid">
                <?php include __DIR__ . '/captcha_puzzle.php'; ?>
            </div>

            <input type="hidden" name="captcha_order" id="captchaOrder" value="">

            <button type="button" class="puzzle-refresh" id="puzzleRefresh">
                🔄 Перемешать
            </button>
        </div>
        <!-- ===== /ПАЗЛ ===== -->

        <button type="submit" style="width:100%; margin-top:10px;">Войти</button>
    </form>

    <p style="margin-top:20px; text-align:center; font-size:13px; color:#6b7280;">
        После <?= $MAX_ATTEMPTS ?> неудачных попыток аккаунт блокируется.
    </p>

    <p style="margin-top:20px; text-align:center;">
        Нет аккаунта? <a href="register.php" class="link">Зарегистрироваться</a>
    </p>
</div>

<script src="assets/captcha.js"></script>
</body>
</html>