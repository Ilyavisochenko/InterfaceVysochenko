<?php
/**
 * Генератор пазл-капчи.
 * Формирует HTML-сетку 2×2 со случайно перемешанными фрагментами.
 * Правильный порядок сохраняется в сессии.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Правильный порядок
$correctOrder = [1, 2, 3, 4];

// Перемешиваем для отображения
$shuffled = $correctOrder;
shuffle($shuffled);

// Сохраняем правильный порядок в сессии
$_SESSION['captcha_puzzle_correct'] = $correctOrder;
$_SESSION['captcha_puzzle_created'] = time();

// Отдаём HTML
header('Content-Type: text/html; charset=utf-8');

foreach ($shuffled as $id) {
    echo '<div class="puzzle-piece" draggable="true" data-id="' . $id . '">';
    echo '<img src="assets/images/' . $id . '.png" alt="Фрагмент ' . $id . '">';
    echo '</div>';
}