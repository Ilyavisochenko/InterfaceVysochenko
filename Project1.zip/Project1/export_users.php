<?php
/**
 * export_users.php — экспорт пользователей в JSON
 * Доступ: только admin и sysadmin
 */
require_once 'config.php';
require_once 'functions.php';
requireAdmin();

// Параметры фильтрации (как в admin.php)
$search     = trim($_GET['search'] ?? '');
$roleFilter = $_GET['role'] ?? '';
$statusFilter = $_GET['status'] ?? '';

$sql = "SELECT * FROM users WHERE 1=1";
if ($search) {
    $s = mysqli_real_escape_string($connection, $search);
    $sql .= " AND (login LIKE '%$s%' OR first_name LIKE '%$s%' OR last_name LIKE '%$s%' OR email LIKE '%$s%')";
}
if ($roleFilter) {
    $r = mysqli_real_escape_string($connection, $roleFilter);
    $sql .= " AND role = '$r'";
}
if ($statusFilter === 'blocked') $sql .= " AND is_blocked = 1";
if ($statusFilter === 'active')  $sql .= " AND is_blocked = 0";
$sql .= " ORDER BY id DESC";

$res = mysqli_query($connection, $sql);
$users = [];
while ($row = mysqli_fetch_assoc($res)) {
    $users[] = [
        'id'              => (int)$row['id'],
        'login'           => $row['login'],
        'first_name'      => $row['first_name'],
        'last_name'       => $row['last_name'],
        'middle_name'     => $row['middle_name'],
        'email'           => $row['email'],
        'birthday'        => $row['birthday'],
        'role'            => $row['role'],
        'is_blocked'      => (bool)$row['is_blocked'],
        'failed_attempts' => (int)$row['failed_attempts'],
        'last_failed_at'  => $row['last_failed_at'],
        'created_at'      => $row['created_at'],
    ];
}

// Формируем итоговый JSON
$export = [
    'meta' => [
        'exported_at'   => date('Y-m-d H:i:s'),
        'exported_by'   => $_SESSION['login'] ?? 'unknown',
        'total_count'   => count($users),
        'filters'       => [
            'search'  => $search ?: null,
            'role'    => $roleFilter ?: null,
            'status'  => $statusFilter ?: null,
        ],
    ],
    'users' => $users,
];

// Отдаём файл на скачивание
$filename = 'users_export_' . date('Y-m-d_H-i-s') . '.json';
header('Content-Type: application/json; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-cache, no-store, must-revalidate');

echo json_encode($export, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
exit;