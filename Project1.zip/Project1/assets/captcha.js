/**
 * Пазл-капча: перетаскивание плиток с обменом местами.
 * JS только меняет местами и собирает порядок.
 * Решение о правильности принимает СЕРВЕР.
 */

document.addEventListener('DOMContentLoaded', function () {
    const grid       = document.getElementById('puzzleGrid');
    const hiddenInp  = document.getElementById('captchaOrder');
    const refreshBtn = document.getElementById('puzzleRefresh');

    if (!grid || !hiddenInp) return;

    let dragged = null;

    function attachHandlers() {
        const pieces = grid.querySelectorAll('.puzzle-piece');

        pieces.forEach(piece => {
            // --- Начало перетаскивания ---
            piece.addEventListener('dragstart', function (e) {
                dragged = piece;
                piece.classList.add('dragging');
                e.dataTransfer.effectAllowed = 'move';
                // Для Firefox обязательно установить data
                e.dataTransfer.setData('text/plain', piece.dataset.id);
            });

            // --- Конец перетаскивания ---
            piece.addEventListener('dragend', function () {
                piece.classList.remove('dragging');
                dragged = null;
                // Убираем все подсветки
                grid.querySelectorAll('.puzzle-piece').forEach(p => {
                    p.classList.remove('drag-over');
                });
                updateOrder();
            });

            // --- Разрешаем drop ---
            piece.addEventListener('dragover', function (e) {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
            });

            piece.addEventListener('dragenter', function (e) {
                e.preventDefault();
                if (piece !== dragged) {
                    piece.classList.add('drag-over');
                }
            });

            piece.addEventListener('dragleave', function () {
                piece.classList.remove('drag-over');
            });

            // --- САМ ОБМЕН ---
            piece.addEventListener('drop', function (e) {
                e.preventDefault();
                e.stopPropagation();
                piece.classList.remove('drag-over');

                if (!dragged || dragged === piece) return;

                // Меняем местами dragged и piece через swap
                swapElements(dragged, piece);

                dragged = null;
                updateOrder();
            });
        });

        updateOrder();
    }

    /**
     * Меняет два DOM-элемента местами.
     * Работает даже если у них разные родители (но тут — один grid).
     */
    function swapElements(a, b) {
        const aNext = a.nextSibling;
        const bNext = b.nextSibling;
        const aParent = a.parentNode;
        const bParent = b.parentNode;

        // Если a и b — соседи
        if (aNext === b) {
            aParent.insertBefore(b, a);
            return;
        }
        if (bNext === a) {
            bParent.insertBefore(a, b);
            return;
        }

        // Общий случай: ставим маркер
        const marker = document.createElement('span');
        aParent.insertBefore(marker, a);
        bParent.insertBefore(a, b);
        aParent.insertBefore(b, marker);
        aParent.removeChild(marker);
    }

    /**
     * Собираем порядок плиток в скрытое поле.
     */
    function updateOrder() {
        const ids = Array.from(grid.querySelectorAll('.puzzle-piece'))
            .map(p => p.dataset.id);
        hiddenInp.value = ids.join(',');
    }

    // --- Кнопка «Перемешать» ---
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function () {
            fetch('captcha_puzzle.php?t=' + Date.now())
                .then(r => r.text())
                .then(html => {
                    grid.innerHTML = html;
                    attachHandlers();
                });
        });
    }

    // Инициализация
    attachHandlers();
});