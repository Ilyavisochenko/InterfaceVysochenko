<?php
/**
 * Функции валидации полей.
 * Возвращают NULL, если поле валидно, или текст ошибки.
 */

function validateLogin(string $login): ?string
{
    if (empty($login)) return 'Логин обязателен';
    if (mb_strlen($login) < 3 || mb_strlen($login) > 30) {
        return 'Логин должен быть от 3 до 30 символов';
    }
    if (!preg_match('/^[A-Za-z0-9_-]+$/', $login)) {
        return 'Логин: только латиница, цифры, _ и -';
    }
    return null;
}

function validateName(string $name, string $field = 'Имя'): ?string
{
    if (empty($name)) return "$field обязательно";
    if (mb_strlen($name) < 2 || mb_strlen($name) > 50) {
        return "$field: от 2 до 50 символов";
    }
    if (!preg_match('/^[А-Яа-яЁёA-Za-z][А-Яа-яЁёA-Za-z-]+$/u', $name)) {
        return "$field: только буквы и дефис";
    }
    return null;
}

function validateEmail(string $email): ?string
{
    if (empty($email)) return 'Email обязателен';
    if (preg_match('/\s/', $email)) return 'Email: пробелы запрещены';
    if (strpos($email, '@') === false) return 'Email должен содержать @';
    if (substr_count($email, '@') !== 1) return 'Email: ровно одна @';
    if ($email[0] === '@') return 'Email не может начинаться с @';
    if (substr($email, -1) === '@') return 'Email не может заканчиваться на @';

    [$local, $domain] = explode('@', $email);

    if (strlen($local) === 0 || strlen($local) > 64) return 'Email: неверная часть до @';
    if (!preg_match('/^[A-Za-z0-9._%+-]+$/', $local)) return 'Email: недопустимые символы до @';
    if ($local[0] === '.' || substr($local, -1) === '.' || strpos($local, '..') !== false) {
        return 'Email: неверные точки до @';
    }
    if (strpos($domain, '.') === false) return 'Email: после @ должна быть точка';
    if ($domain[0] === '.' || substr($domain, -1) === '.' || strpos($domain, '..') !== false) {
        return 'Email: неверный домен';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return 'Email: неверный формат';
    if (strlen($email) > 100) return 'Email слишком длинный';
    return null;
}

function validateBirthday(string $birthday): ?string
{
    if (empty($birthday)) return 'Дата рождения обязательна';

    $date = DateTime::createFromFormat('Y-m-d', $birthday);
    if (!$date || $date->format('Y-m-d') !== $birthday) {
        return 'Дата рождения: формат ГГГГ-ММ-ДД';
    }
    $today = new DateTime('today');
    if ($date > $today) return 'Дата рождения не может быть в будущем';
    $minDate = (new DateTime('today'))->modify('-120 years');
    if ($date < $minDate) return 'Возраст не может превышать 120 лет';
    return null;
}

function validatePassword(string $password): ?string
{
    if (empty($password)) return 'Пароль обязателен';
    if (strlen($password) < 8) return 'Пароль: минимум 8 символов';
    if (strlen($password) > 72) return 'Пароль: не более 72 символов';
    if (!preg_match('/[A-Za-z]/', $password)) return 'Пароль: нужна хотя бы одна буква';
    if (!preg_match('/\d/', $password)) return 'Пароль: нужна хотя бы одна цифра';
    return null;
}

function e(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function isLoggedIn(): bool
{
    return !empty($_SESSION['user_id']);
}

function isAdmin(): bool
{
    // Теперь пускает и обычных админов, и супер-админов
    return isLoggedIn() && in_array(($_SESSION['role'] ?? ''), ['admin', 'sysadmin']);
}

function requireLogin(): void
{
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function requireAdmin(): void
{
    requireLogin();
    if (!isAdmin()) {
        http_response_code(403);
        die('Доступ запрещён: только для администратора');
    }
}