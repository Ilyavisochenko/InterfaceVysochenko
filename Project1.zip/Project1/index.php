<?php
require_once 'config.php';
require_once 'functions.php';

// Получаем заметки (если авторизован)
$notes = [];
if (isLoggedIn()) {
    $isAdmin = isAdmin();
    $userId = $_SESSION['user_id'];

    if ($isAdmin) {
        $sql = "SELECT n.*, u.login FROM notes n JOIN users u ON n.user_id = u.id ORDER BY n.created_at DESC LIMIT 10";
        $stmt = mysqli_prepare($connection, $sql);
    } else {
        $sql = "SELECT n.*, u.login FROM notes n JOIN users u ON n.user_id = u.id WHERE n.user_id = ? ORDER BY n.created_at DESC LIMIT 10";
        $stmt = mysqli_prepare($connection, $sql);
        mysqli_stmt_bind_param($stmt, 'i', $userId);
    }
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($res)) $notes[] = $row;
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная — Система авторизации</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .note-card {
            background: var(--md-surface-2);
            border: 1px solid var(--md-outline-var);
            border-radius: var(--r-md);
            padding: 16px;
            margin-bottom: 12px;
            box-shadow: var(--el-1);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }
        .note-info h4 { margin: 0 0 6px 0; font-size: 15px; color: var(--md-on-surface); font-weight: 600; }
        .note-info p { margin: 0; font-size: 13.5px; color: var(--md-on-surface-var); }
        .note-date { font-size: 12px; color: var(--md-outline); margin-top: 8px; display: flex; align-items: center; gap: 4px; }
        .note-id { font-size: 12px; color: var(--md-outline); font-family: monospace; background: rgba(255,255,255,0.05); padding: 2px 6px; border-radius: 4px; }
    </style>
</head>
<body>
<div class="container">
    <h1>🔐 Система авторизации</h1>

    <?php if (isLoggedIn()): ?>
        <div class="success" style="margin-bottom: 20px;">
            👋 Здравствуйте, <strong><?= e($_SESSION['first_name']) ?></strong>!
            Вы вошли как <strong><?= e($_SESSION['login']) ?></strong>
            (роль: <strong><?= e($_SESSION['role']) ?></strong>)
        </div>

                <div class="menu" style="margin-bottom: 24px;">
            <a href="notes.php" class="btn btn-primary" style="background: #8957e5;">📝 Заметки</a>
            <a href="profile.php" class="btn btn-secondary">👤 Профиль</a>
            <a href="change_password.php" class="btn btn-secondary">🔒 Сменить пароль</a>
            <?php if (isAdmin()): ?>
                <a href="admin.php" class="btn btn-primary" style="background: #238636;">🛡 Админ-панель</a>
            <?php endif; ?>
            <a href="logout.php" class="btn btn-danger">🚪 Выйти</a>
        </div>

    <?php else: ?>
        <p style="text-align:center; color:var(--md-on-surface-var); margin-bottom:20px;">
            Добро пожаловать! Войдите или зарегистрируйтесь.
        </p>
        <div class="menu" style="justify-content: center;">
            <a href="login.php" class="btn btn-primary">🔑 Войти</a>
            <a href="register.php" class="btn btn-secondary">📝 Регистрация</a>
        </div>
    <?php endif; ?>
</div>
</body>
</html>